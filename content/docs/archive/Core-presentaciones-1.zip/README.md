# CORE Executive Experience

**"The Operating System for Commerce"**

Experiencia ejecutiva interactiva para CORE — diseñada para CEOs, inversores, distribuidores, importadores y marcas globales.

---

## Stack
- Next.js 14 (App Router)
- TypeScript
- Tailwind CSS
- Framer Motion
- Supabase

## Instalación

```bash
git clone https://github.com/CharlieUY711/core-presentaciones
cd core-presentaciones
npm install
cp .env.example .env.local
# Completar NEXT_PUBLIC_SUPABASE_URL y NEXT_PUBLIC_SUPABASE_ANON_KEY
npm run dev
```

## Documentación

| Doc | Descripción |
|-----|-------------|
| [00-architecture.md](./docs/00-architecture.md) | Arquitectura completa, rutas, decisiones |
| [01-storyboard.md](./docs/01-storyboard.md) | Storyboard sección por sección |
| [02-design-system.md](./docs/02-design-system.md) | Colores, tipografía, motion, lenguaje visual |
| [03-supabase-i18n.md](./docs/03-supabase-i18n.md) | Tablas Supabase + estrategia i18n |
| [04-component-tree.md](./docs/04-component-tree.md) | Árbol completo de componentes + props |
| [05-checklist.md](./docs/05-checklist.md) | Checklist maestro de punta a punta |

## Claim central

> Others integrate software.  
> **CORE integrates operations.**

---

## Acceso

La experiencia requiere login (Supabase Auth).
Acceso solo por invitación — no hay registro público.
Contactar al equipo CORE para credenciales.
