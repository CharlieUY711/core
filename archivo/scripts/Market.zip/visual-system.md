# CORE Market — Visual System

**ID:** `CORE-PM-MARKET-VISUAL-0001`  
**Versión:** 1.0  
**Fecha:** Junio 2026  
**Clasificación:** Confidencial — Uso interno

---

## 1. Principios

El Market aplica el CORE Visual System en todas las secciones excepto Second Hand, que conserva su identidad verde propia.

---

## 2. Paleta de Colores

### CORE Market (todas las secciones excepto Second Hand)

| Token | Valor | Uso |
|-------|-------|-----|
| `--bg` | `#F2F5FA` | Fondo principal |
| `--surface` | `#FFFFFF` | Superficies y cards |
| `--text` | `#0D2B55` | Texto principal (Navy CORE) |
| `--muted` | `#7A7A7A` | Texto secundario |
| `--accent` | `#C9A84C` | Acento Gold CORE |
| `--accent2` | `#1A4F9C` | Acento Blue CORE |
| `--line` | `#C8D5E8` | Bordes |
| `--cyan` | `#2E6FC4` | Blue Light CORE |

### ⚠️ Second Hand — Identidad Verde (NO modificar)

| Token | Valor | Uso |
|-------|-------|-----|
| `--bg` | `#E5EDE8` | Fondo Second Hand |
| `--surface` | `#EEF4F0` | Superficies Second Hand |
| `--text` | `#0D1F12` | Texto Second Hand |
| `--muted` | `#5A7A64` | Texto secundario Second Hand |
| `--accent` | `#6BB87A` | Verde principal Second Hand |
| `--accent2` | `#68C018` | Verde acento Second Hand |

Implementado via `[data-sh="true"]` en el CSS original del storefront. No modificar bajo ninguna circunstancia.

---

## 3. Tipografía

| Elemento | Fuente | Tamaño | Peso |
|----------|--------|--------|------|
| Body | Calibri, Segoe UI, system-ui | 14px / 1rem | 400 |
| Labels | Calibri, Segoe UI, system-ui | 11px | 600 |
| Títulos | Calibri, Segoe UI, system-ui | 1.5rem–2rem | 700 |
| Mono / Precios | Calibri, Segoe UI | 13px | 700 |

```css
--font-base: Calibri, 'Segoe UI', system-ui, sans-serif;
```

---

## 4. Espaciado — Base 8px

| Token | Valor |
|-------|-------|
| `--space-1` | 4px |
| `--space-2` | 8px |
| `--space-3` | 12px |
| `--space-4` | 16px |
| `--space-5` | 24px |
| `--space-6` | 32px |
| `--space-7` | 48px |
| `--space-8` | 64px |

---

## 5. Radios

| Token | Valor |
|-------|-------|
| `--radius-sm` | 4px |
| `--radius-md` | 8px |
| `--radius-lg` | 12px |
| `--radius-xl` | 16px |
| `--radius-pill` | 999px |

---

## 6. Sombras

| Token | Valor |
|-------|-------|
| `--shadow-sm` | `0 1px 3px rgba(13,43,85,.06)` |
| `--shadow-md` | `0 2px 8px rgba(13,43,85,.09)` |
| `--shadow-lg` | `0 8px 24px rgba(13,43,85,.14)` |
| `--shadow-card` | `0 2px 8px rgba(13,43,85,.08)` |

---

## 7. Componentes

### Navbar / Header
- Fondo: `#0D2B55` (Navy CORE)
- Texto: `rgba(232,237,245,.75)`
- Hover: `#C9A84C` (Gold CORE)
- Border bottom: `1px solid rgba(201,168,76,.2)`

### Botones
- Primario: bg `#1A4F9C`, hover `#0D2B55`, texto blanco
- Secundario: outline `#C8D5E8`, hover border `#1A4F9C`
- Ghost: texto `#7A7A7A`, hover color `#1A4F9C`
- Border radius: `4px`
- Font: 11px, 600 weight, tracking 0.1em, uppercase

### Cards de producto
- Fondo: `#FFFFFF`
- Border: `1px solid #C8D5E8`
- Border radius: `8px`
- Shadow: `0 2px 8px rgba(13,43,85,.06)`
- Hover: shadow `0 8px 24px rgba(13,43,85,.12)` + `translateY(-2px)`

### Inputs / Search
- Border: `1px solid #C8D5E8`
- Focus border: `#1A4F9C`
- Focus ring: `0 0 0 3px rgba(26,79,156,.1)`
- Border radius: `4px`

### Sidebar Admin
- Fondo: `#0D2B55` (Navy CORE)
- Active: border-left `3px solid #C9A84C`, bg `rgba(201,168,76,.1)`
- Hover: `rgba(255,255,255,.06)`

### Footer
- Fondo: `#0D2B55`
- Texto: `rgba(232,237,245,.6)`
- Border top: `1px solid rgba(201,168,76,.15)`
- Link hover: `#C9A84C`

---

## 8. Animaciones

| Elemento | Comportamiento |
|----------|---------------|
| Cards hover | `translateY(-2px)` + shadow, 200ms ease-in-out |
| Botones | color transition 200ms ease-in-out |
| Inputs focus | border + ring, 200ms ease-in-out |
| Page load | fadeInUp 300ms ease-out |
| Links nav | color transition 200ms ease-in-out |

```css
@keyframes fadeInUp {
  from { opacity: 0; transform: translateY(8px); }
  to   { opacity: 1; transform: translateY(0); }
}
```

Respetar `prefers-reduced-motion`.

---

## 9. Archivos CSS del Market

| Archivo | Ubicación | Descripción |
|---------|-----------|-------------|
| `brand.css` | `src/styles/brand.css` | Tokens de marca CORE |
| `theme.css` | `src/styles/theme.css` | Componentes UI CORE |
| `core-market-patch.css` | `src/styles/core-market-patch.css` | Patch visual CORE sobre storefront |
| `legacy-storefront.css` | `src/styles/legacy-storefront.css` | CSS original del storefront — contiene `[data-sh]` verde |

---

*CORE Market — Visual System v1.0 · Junio 2026 · Confidencial — Uso interno*
