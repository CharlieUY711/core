# CORE Market — Documentación

Documentación oficial del producto CORE Market.

## Índice

- [Arquitectura](./architecture.md)
