# CORE Market — Prompts Oficiales

| ID | Descripción |
|----|-------------|
| [CORE-PM-MARKET-MIGRATION-0001](./CORE-PM-MARKET-MIGRATION-0001.md) | Migración al monorepo CORE |
| [CORE-PM-MARKET-RESTRUCTURE-0001](./CORE-PM-MARKET-RESTRUCTURE-0001.md) | Reestructuración como producto independiente |
