import { createClient } from "@/lib/supabase/server";
import Link from "next/link";
import { FolderOpen, Plus, Clock } from "lucide-react";

export const metadata = { title: "Proyectos" };

const STATUS_LABELS: Record<string, { label: string; color: string }> = {
  draft:     { label: "Borrador",    color: "bg-gray-100 text-gray-600" },
  active:    { label: "Activo",      color: "bg-green-100 text-green-700" },
  on_hold:   { label: "En pausa",    color: "bg-yellow-100 text-yellow-700" },
  submitted: { label: "Presentado",  color: "bg-blue-100 text-blue-700" },
  awarded:   { label: "Adjudicado",  color: "bg-brand-100 text-brand-700" },
  lost:      { label: "No adjud.",   color: "bg-red-100 text-red-600" },
  closed:    { label: "Cerrado",     color: "bg-gray-100 text-gray-500" },
};

export default async function ProjectsPage() {
  const supabase = createClient();

  const { data: projects, error } = await supabase
    .from("projects")
    .select(`
      id, code, name, description, status, currency, deadline, created_at,
      workspaces ( name, organizations ( name ) )
    `)
    .order("created_at", { ascending: false });

  if (error) {
    return <p className="text-red-600 text-sm">Error cargando proyectos: {error.message}</p>;
  }

  return (
    <div>
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900">Proyectos</h1>
          <p className="text-sm text-gray-500 mt-1">
            {projects?.length ?? 0} proyecto{projects?.length !== 1 ? "s" : ""} en tu organización
          </p>
        </div>
        <Link href="/projects/new" className="bep-btn-primary">
          <Plus size={16} />
          Nuevo proyecto
        </Link>
      </div>

      {/* Projects grid */}
      {!projects?.length ? (
        <div className="bep-card p-16 text-center">
          <FolderOpen size={40} className="mx-auto text-gray-300 mb-4" />
          <p className="text-gray-500 font-medium">No hay proyectos todavía</p>
          <p className="text-sm text-gray-400 mt-1">
            Creá tu primer proyecto para comenzar.
          </p>
          <Link href="/projects/new" className="bep-btn-primary mt-6 inline-flex">
            <Plus size={16} /> Crear proyecto
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {projects.map((project) => {
            const ws = project.workspaces as any;
            const org = ws?.organizations as any;
            const statusMeta = STATUS_LABELS[project.status] ?? STATUS_LABELS.draft;

            return (
              <Link
                key={project.id}
                href={`/projects/${project.id}`}
                className="bep-card p-5 hover:shadow-md transition-shadow block"
              >
                {/* Org / Workspace breadcrumb */}
                <p className="text-xs text-gray-400 mb-2 font-medium uppercase tracking-wide">
                  {org?.name} › {ws?.name}
                </p>

                {/* Code + status */}
                <div className="flex items-start justify-between gap-3 mb-2">
                  <span className="text-xs font-mono text-gray-500 bg-gray-100 px-2 py-0.5 rounded">
                    {project.code}
                  </span>
                  <span className={`bep-badge ${statusMeta.color}`}>
                    {statusMeta.label}
                  </span>
                </div>

                {/* Name */}
                <h2 className="font-medium text-gray-900 text-sm leading-snug mb-2 line-clamp-2">
                  {project.name}
                </h2>

                {/* Description */}
                {project.description && (
                  <p className="text-xs text-gray-500 line-clamp-2 mb-3">
                    {project.description}
                  </p>
                )}

                {/* Footer */}
                <div className="flex items-center gap-2 text-xs text-gray-400 pt-3 border-t border-gray-100">
                  <Clock size={12} />
                  {project.deadline
                    ? `Vence ${new Date(project.deadline).toLocaleDateString("es-UY")}`
                    : `Creado ${new Date(project.created_at).toLocaleDateString("es-UY")}`}
                </div>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
