import { createClient } from "@/lib/supabase/server";
import Link from "next/link";
import { ArrowLeft, FileText, Upload, Clock } from "lucide-react";

const STATUS_COLORS: Record<string, string> = {
  pending:    "bg-gray-100 text-gray-600",
  processing: "bg-yellow-100 text-yellow-700",
  indexed:    "bg-green-100 text-green-700",
  error:      "bg-red-100 text-red-600",
};

const TYPE_LABELS: Record<string, string> = {
  pliego:        "Pliego",
  plano:         "Plano",
  anexo:         "Anexo",
  norma:         "Norma",
  contrato:      "Contrato",
  memoria:       "Memoria",
  ficha_tecnica: "Ficha técnica",
  catalogo:      "Catálogo",
  rfq:           "RFQ",
  cotizacion:    "Cotización",
  circular:      "Circular",
  consulta:      "Consulta",
  correo:        "Correo",
  otro:          "Otro",
};

export default async function DocumentsPage({
  params,
}: {
  params: { id: string };
}) {
  const supabase = createClient();

  const [{ data: project }, { data: documents }] = await Promise.all([
    supabase.from("projects").select("name, code").eq("id", params.id).single(),
    supabase
      .from("documents")
      .select("id, name, type, status, discipline, version, size_bytes, created_at, ai_tags")
      .eq("project_id", params.id)
      .order("created_at", { ascending: false }),
  ]);

  const formatBytes = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <div>
      <Link
        href={`/projects/${params.id}`}
        className="inline-flex items-center gap-1 text-sm text-gray-500 hover:text-gray-800 mb-6"
      >
        <ArrowLeft size={14} />
        {project?.code} — {project?.name}
      </Link>

      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-semibold text-gray-900">Documentos</h1>
          <p className="text-sm text-gray-500 mt-0.5">
            {documents?.length ?? 0} documentos · Procesamiento IA automático
          </p>
        </div>
        <Link
          href={`/projects/${params.id}/documents/upload`}
          className="bep-btn-primary"
        >
          <Upload size={15} />
          Subir documentos
        </Link>
      </div>

      {!documents?.length ? (
        <div className="bep-card p-16 text-center">
          <FileText size={40} className="mx-auto text-gray-200 mb-4" />
          <p className="text-gray-500 font-medium">Sin documentos todavía</p>
          <p className="text-sm text-gray-400 mt-1 mb-6">
            Subí el pliego, planos, anexos y cualquier documento del proyecto.
            La IA los procesará automáticamente.
          </p>
          <Link
            href={`/projects/${params.id}/documents/upload`}
            className="bep-btn-primary inline-flex"
          >
            <Upload size={15} /> Subir primer documento
          </Link>
        </div>
      ) : (
        <div className="bep-card overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-100 bg-gray-50">
                <th className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase tracking-wide">Nombre</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase tracking-wide">Tipo</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase tracking-wide">Disciplina</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase tracking-wide">Estado IA</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase tracking-wide">Ver.</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase tracking-wide">Tamaño</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase tracking-wide">Fecha</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {documents.map((doc) => (
                <tr key={doc.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <FileText size={14} className="text-gray-400 flex-shrink-0" />
                      <Link
                        href={`/projects/${params.id}/documents/${doc.id}`}
                        className="font-medium text-gray-900 hover:text-brand-600 truncate max-w-xs"
                      >
                        {doc.name}
                      </Link>
                    </div>
                    {doc.ai_tags?.length > 0 && (
                      <div className="flex gap-1 mt-1 ml-5">
                        {doc.ai_tags.slice(0, 3).map((tag: string) => (
                          <span key={tag} className="text-xs bg-brand-50 text-brand-700 px-1.5 py-0.5 rounded">
                            {tag}
                          </span>
                        ))}
                      </div>
                    )}
                  </td>
                  <td className="px-4 py-3 text-gray-600">
                    {TYPE_LABELS[doc.type] ?? doc.type}
                  </td>
                  <td className="px-4 py-3 text-gray-500">
                    {doc.discipline ?? "—"}
                  </td>
                  <td className="px-4 py-3">
                    <span className={`bep-badge ${STATUS_COLORS[doc.status]}`}>
                      {doc.status}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-gray-500 text-xs">v{doc.version}</td>
                  <td className="px-4 py-3 text-gray-500 text-xs">
                    {formatBytes(doc.size_bytes)}
                  </td>
                  <td className="px-4 py-3 text-gray-400 text-xs">
                    <span className="flex items-center gap-1">
                      <Clock size={11} />
                      {new Date(doc.created_at).toLocaleDateString("es-UY")}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
