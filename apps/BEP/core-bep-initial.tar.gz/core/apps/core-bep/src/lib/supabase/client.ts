"use client";

import { createBrowserClient } from "@supabase/ssr";
import type { Database } from "@core/supabase/bep/types";

export function createClient() {
  return createBrowserClient<Database>(
    process.env.NEXT_PUBLIC_BEP_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_BEP_SUPABASE_ANON_KEY!
  );
}
