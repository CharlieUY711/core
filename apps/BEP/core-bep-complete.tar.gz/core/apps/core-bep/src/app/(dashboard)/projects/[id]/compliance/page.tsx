import { createClient } from "@/lib/supabase/server";
import Link from "next/link";
import { ArrowLeft, CheckSquare, AlertCircle, Clock, CheckCircle2, XCircle } from "lucide-react";

const STATUS_CONFIG: Record<string, { label: string; color: string; icon: typeof CheckCircle2 }> = {
  pending:             { label: "Pendiente",          color: "bg-gray-100 text-gray-600",   icon: Clock },
  in_review:           { label: "En revisión",        color: "bg-yellow-100 text-yellow-700", icon: Clock },
  compliant:           { label: "Cumple",             color: "bg-green-100 text-green-700",  icon: CheckCircle2 },
  non_compliant:       { label: "No cumple",          color: "bg-red-100 text-red-600",     icon: XCircle },
  exception_requested: { label: "Excepción solicit.", color: "bg-orange-100 text-orange-700", icon: AlertCircle },
  waived:              { label: "Eximido",            color: "bg-purple-100 text-purple-700", icon: CheckCircle2 },
};

export default async function CompliancePage({ params }: { params: { id: string } }) {
  const supabase = createClient();

  const [{ data: project }, { data: matrix }] = await Promise.all([
    supabase.from("projects").select("name, code").eq("id", params.id).single(),
    supabase
      .from("compliance_matrix")
      .select(`
        id, status, evidence, notes, reviewed_at,
        requirements ( article_ref, text, type, discipline ),
        documents ( name ),
        bom_lines ( code, description ),
        manufacturers ( name )
      `)
      .eq("project_id", params.id)
      .order("created_at", { ascending: true }),
  ]);

  // Aggregate stats
  const stats = Object.keys(STATUS_CONFIG).reduce(
    (acc, key) => ({
      ...acc,
      [key]: matrix?.filter((m) => m.status === key).length ?? 0,
    }),
    {} as Record<string, number>
  );
  const total = matrix?.length ?? 0;
  const pct = total > 0 ? Math.round(((stats.compliant ?? 0) / total) * 100) : 0;

  return (
    <div>
      <Link
        href={`/projects/${params.id}`}
        className="inline-flex items-center gap-1 text-sm text-gray-500 hover:text-gray-800 mb-6"
      >
        <ArrowLeft size={14} /> {project?.code} — {project?.name}
      </Link>

      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-semibold text-gray-900">Matriz de Cumplimiento</h1>
          <p className="text-sm text-gray-500 mt-0.5">
            {total} requisitos · {pct}% cumplimiento
          </p>
        </div>
        <div className="flex gap-2">
          <button className="bep-btn-secondary text-sm">Exportar PDF</button>
          <button className="bep-btn-primary">✨ Actualizar con IA</button>
        </div>
      </div>

      {/* Progress bar */}
      <div className="bep-card p-5 mb-6">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium text-gray-700">Progreso de cumplimiento</span>
          <span className="text-sm font-semibold text-gray-900">{pct}%</span>
        </div>
        <div className="w-full bg-gray-100 rounded-full h-2.5 mb-4">
          <div
            className="bg-green-500 h-2.5 rounded-full transition-all"
            style={{ width: `${pct}%` }}
          />
        </div>
        <div className="grid grid-cols-3 md:grid-cols-6 gap-3">
          {Object.entries(STATUS_CONFIG).map(([key, { label, color }]) => (
            <div key={key} className="text-center">
              <p className="text-lg font-semibold text-gray-900">{stats[key] ?? 0}</p>
              <span className={`bep-badge ${color} mt-1`}>{label}</span>
            </div>
          ))}
        </div>
      </div>

      {!matrix?.length ? (
        <div className="bep-card p-16 text-center">
          <CheckSquare size={40} className="mx-auto text-gray-200 mb-4" />
          <p className="text-gray-500 font-medium">Matriz vacía</p>
          <p className="text-sm text-gray-400 mt-1 mb-6">
            La IA puede generar la matriz automáticamente desde los requisitos del pliego.
          </p>
          <button className="bep-btn-primary inline-flex">✨ Generar con IA</button>
        </div>
      ) : (
        <div className="bep-card overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-100 bg-gray-50">
                <th className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase tracking-wide">Artículo</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase tracking-wide">Requisito</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase tracking-wide">Tipo</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase tracking-wide">Documento</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase tracking-wide">BOM</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase tracking-wide">Fabricante</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase tracking-wide">Evidencia</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase tracking-wide">Estado</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {matrix.map((row) => {
                const req = row.requirements as any;
                const doc = row.documents as any;
                const bom = row.bom_lines as any;
                const mfr = row.manufacturers as any;
                const statusCfg = STATUS_CONFIG[row.status] ?? STATUS_CONFIG.pending;
                const Icon = statusCfg.icon;

                return (
                  <tr key={row.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-4 py-3 font-mono text-xs text-gray-600 whitespace-nowrap">
                      {req?.article_ref ?? "—"}
                    </td>
                    <td className="px-4 py-3 max-w-xs">
                      <p className="text-gray-800 text-xs leading-relaxed line-clamp-3">{req?.text}</p>
                    </td>
                    <td className="px-4 py-3 text-xs text-gray-500 capitalize">{req?.type ?? "—"}</td>
                    <td className="px-4 py-3 text-xs text-gray-600">{doc?.name ?? "—"}</td>
                    <td className="px-4 py-3 text-xs font-mono text-gray-600">{bom?.code ?? "—"}</td>
                    <td className="px-4 py-3 text-xs text-gray-600">{mfr?.name ?? "—"}</td>
                    <td className="px-4 py-3 text-xs text-gray-500 max-w-[160px]">
                      <p className="line-clamp-2">{row.evidence ?? "—"}</p>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`bep-badge ${statusCfg.color} gap-1`}>
                        <Icon size={11} />
                        {statusCfg.label}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
