import { createClient } from "@/lib/supabase/server";
import Link from "next/link";
import { ArrowLeft, BookOpen, Lightbulb, GitBranch, Plus } from "lucide-react";

export default async function KnowledgePage({ params }: { params: { id: string } }) {
  const supabase = createClient();

  const [{ data: project }, { data: decisions }, { data: lessons }] = await Promise.all([
    supabase.from("projects").select("name, code").eq("id", params.id).single(),
    supabase
      .from("decisions")
      .select("id, title, rationale, decided_at, linked_entities")
      .eq("project_id", params.id)
      .order("decided_at", { ascending: false }),
    supabase
      .from("lessons_learned")
      .select("id, category, description, impact, recommendation, created_at")
      .eq("project_id", params.id)
      .order("created_at", { ascending: false }),
  ]);

  // Group lessons by category
  const lessonsByCategory = (lessons ?? []).reduce(
    (acc, lesson) => {
      const cat = lesson.category || "General";
      if (!acc[cat]) acc[cat] = [];
      acc[cat].push(lesson);
      return acc;
    },
    {} as Record<string, typeof lessons>
  );

  return (
    <div>
      <Link
        href={`/projects/${params.id}`}
        className="inline-flex items-center gap-1 text-sm text-gray-500 hover:text-gray-800 mb-6"
      >
        <ArrowLeft size={14} /> {project?.code} — {project?.name}
      </Link>

      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-semibold text-gray-900">Wiki Técnica</h1>
          <p className="text-sm text-gray-500 mt-0.5">
            Decisiones, lecciones aprendidas y conocimiento del proyecto
          </p>
        </div>
        <div className="flex gap-2">
          <Link href={`/projects/${params.id}/knowledge/new-lesson`} className="bep-btn-secondary">
            <Lightbulb size={14} /> Nueva lección
          </Link>
          <Link href={`/projects/${params.id}/knowledge/new-decision`} className="bep-btn-primary">
            <Plus size={14} /> Registrar decisión
          </Link>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

        {/* Decisions */}
        <div>
          <h2 className="text-sm font-medium text-gray-700 mb-3 flex items-center gap-2">
            <GitBranch size={15} className="text-gray-400" />
            Decisiones técnicas ({decisions?.length ?? 0})
          </h2>

          {!decisions?.length ? (
            <div className="bep-card p-10 text-center">
              <GitBranch size={28} className="mx-auto text-gray-200 mb-3" />
              <p className="text-sm text-gray-500 mb-1">Sin decisiones registradas</p>
              <p className="text-xs text-gray-400 mb-4">
                Documentá cada decisión técnica para no perder el conocimiento del proyecto.
              </p>
              <Link
                href={`/projects/${params.id}/knowledge/new-decision`}
                className="bep-btn-primary text-xs inline-flex"
              >
                <Plus size={13} /> Registrar decisión
              </Link>
            </div>
          ) : (
            <div className="space-y-3">
              {decisions.map((d) => {
                const linked = (d.linked_entities as any[]) ?? [];
                return (
                  <div key={d.id} className="bep-card p-4">
                    <div className="flex items-start justify-between gap-3 mb-2">
                      <h3 className="font-medium text-gray-900 text-sm">{d.title}</h3>
                      <span className="text-xs text-gray-400 whitespace-nowrap">
                        {new Date(d.decided_at).toLocaleDateString("es-UY")}
                      </span>
                    </div>
                    <p className="text-xs text-gray-600 leading-relaxed line-clamp-3 mb-2">
                      {d.rationale}
                    </p>
                    {linked.length > 0 && (
                      <div className="flex gap-1 flex-wrap">
                        {linked.slice(0, 4).map((e: any, i: number) => (
                          <span key={i} className="text-xs bg-gray-100 text-gray-500 px-2 py-0.5 rounded">
                            {e.type}: {e.ref ?? e.id?.slice(0, 8)}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Lessons Learned */}
        <div>
          <h2 className="text-sm font-medium text-gray-700 mb-3 flex items-center gap-2">
            <Lightbulb size={15} className="text-gray-400" />
            Lecciones aprendidas ({lessons?.length ?? 0})
          </h2>

          {!lessons?.length ? (
            <div className="bep-card p-10 text-center">
              <Lightbulb size={28} className="mx-auto text-gray-200 mb-3" />
              <p className="text-sm text-gray-500 mb-1">Sin lecciones registradas</p>
              <p className="text-xs text-gray-400 mb-4">
                Cada lección queda en la base de conocimiento corporativa para proyectos futuros.
              </p>
              <Link
                href={`/projects/${params.id}/knowledge/new-lesson`}
                className="bep-btn-secondary text-xs inline-flex"
              >
                <Lightbulb size={13} /> Agregar lección
              </Link>
            </div>
          ) : (
            <div className="space-y-4">
              {Object.entries(lessonsByCategory).map(([category, items]) => (
                <div key={category}>
                  <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">
                    {category}
                  </p>
                  <div className="space-y-2">
                    {items!.map((lesson) => (
                      <div key={lesson.id} className="bep-card p-4">
                        <p className="text-sm text-gray-800 font-medium mb-1">{lesson.description}</p>
                        {lesson.impact && (
                          <p className="text-xs text-gray-500 mb-1">
                            <span className="font-medium">Impacto:</span> {lesson.impact}
                          </p>
                        )}
                        {lesson.recommendation && (
                          <div className="bg-brand-50 rounded-lg px-3 py-2 mt-2">
                            <p className="text-xs text-brand-800">
                              💡 {lesson.recommendation}
                            </p>
                          </div>
                        )}
                        <p className="text-xs text-gray-400 mt-2">
                          {new Date(lesson.created_at).toLocaleDateString("es-UY")}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
