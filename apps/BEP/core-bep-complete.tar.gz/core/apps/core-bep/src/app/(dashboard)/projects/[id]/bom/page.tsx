import { createClient } from "@/lib/supabase/server";
import Link from "next/link";
import { ArrowLeft, List, Plus, ChevronRight } from "lucide-react";

const STATUS_COLORS: Record<string, string> = {
  draft:        "bg-gray-100 text-gray-600",
  under_review: "bg-yellow-100 text-yellow-700",
  approved:     "bg-green-100 text-green-700",
  rfq_sent:     "bg-blue-100 text-blue-700",
  quoted:       "bg-purple-100 text-purple-700",
  ordered:      "bg-orange-100 text-orange-700",
  delivered:    "bg-teal-100 text-teal-700",
};

const STATUS_LABELS: Record<string, string> = {
  draft:        "Borrador",
  under_review: "En revisión",
  approved:     "Aprobado",
  rfq_sent:     "RFQ enviado",
  quoted:       "Cotizado",
  ordered:      "Pedido",
  delivered:    "Entregado",
};

export default async function BomPage({ params }: { params: { id: string } }) {
  const supabase = createClient();

  const [{ data: project }, { data: lines }] = await Promise.all([
    supabase.from("projects").select("name, code, currency").eq("id", params.id).single(),
    supabase
      .from("bom_lines")
      .select(`
        id, level, code, description, quantity, unit, status, discipline, version, notes,
        manufacturers ( name ),
        products ( name, code )
      `)
      .eq("project_id", params.id)
      .order("code", { ascending: true }),
  ]);

  // Stats
  const total = lines?.length ?? 0;
  const approved = lines?.filter((l) => l.status === "approved").length ?? 0;
  const pending = lines?.filter((l) => ["draft", "under_review"].includes(l.status)).length ?? 0;
  const quoted = lines?.filter((l) => ["quoted", "rfq_sent"].includes(l.status)).length ?? 0;

  return (
    <div>
      <Link
        href={`/projects/${params.id}`}
        className="inline-flex items-center gap-1 text-sm text-gray-500 hover:text-gray-800 mb-6"
      >
        <ArrowLeft size={14} /> {project?.code} — {project?.name}
      </Link>

      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-semibold text-gray-900">BOM Master</h1>
          <p className="text-sm text-gray-500 mt-0.5">Lista maestra de materiales y equipos</p>
        </div>
        <div className="flex gap-2">
          <button className="bep-btn-secondary text-sm">Exportar XLSX</button>
          <Link href={`/projects/${params.id}/bom/new`} className="bep-btn-primary">
            <Plus size={15} /> Agregar línea
          </Link>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-3 mb-6">
        {[
          { label: "Total líneas", value: total,    color: "text-gray-900" },
          { label: "Aprobadas",    value: approved, color: "text-green-700" },
          { label: "Pendientes",   value: pending,  color: "text-yellow-700" },
          { label: "En cotización",value: quoted,   color: "text-blue-700" },
        ].map(({ label, value, color }) => (
          <div key={label} className="bep-card p-4">
            <p className={`text-2xl font-semibold ${color}`}>{value}</p>
            <p className="text-xs text-gray-500 mt-0.5">{label}</p>
          </div>
        ))}
      </div>

      {!lines?.length ? (
        <div className="bep-card p-16 text-center">
          <List size={40} className="mx-auto text-gray-200 mb-4" />
          <p className="text-gray-500 font-medium">BOM vacío</p>
          <p className="text-sm text-gray-400 mt-1 mb-6">
            Podés agregar líneas manualmente o dejar que la IA lo genere desde los documentos del proyecto.
          </p>
          <div className="flex gap-3 justify-center">
            <Link href={`/projects/${params.id}/bom/new`} className="bep-btn-primary inline-flex">
              <Plus size={15} /> Agregar línea
            </Link>
            <button className="bep-btn-secondary">✨ Generar con IA</button>
          </div>
        </div>
      ) : (
        <div className="bep-card overflow-hidden">
          {/* AI generate banner */}
          <div className="bg-brand-50 border-b border-brand-100 px-4 py-3 flex items-center justify-between">
            <p className="text-sm text-brand-800">
              ✨ La IA puede completar fabricantes, cantidades y productos basándose en los documentos del proyecto.
            </p>
            <button className="text-xs text-brand-700 font-medium underline hover:no-underline">
              Generar con IA
            </button>
          </div>

          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-100 bg-gray-50">
                <th className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase tracking-wide w-8">Niv.</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase tracking-wide">Código</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase tracking-wide">Descripción</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase tracking-wide">Cant.</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase tracking-wide">Disciplina</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase tracking-wide">Fabricante</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase tracking-wide">Estado</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase tracking-wide">Ver.</th>
                <th className="px-4 py-3 w-8" />
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {lines.map((line) => {
                const mfr = line.manufacturers as any;
                const prod = line.products as any;
                return (
                  <tr key={line.id} className="hover:bg-gray-50 transition-colors group">
                    <td className="px-4 py-3 text-gray-400 text-xs">{line.level}</td>
                    <td className="px-4 py-3 font-mono text-xs text-gray-600 whitespace-nowrap">
                      {"  ".repeat(Math.max(0, line.level - 1))}{line.code}
                    </td>
                    <td className="px-4 py-3">
                      <p className="font-medium text-gray-900">{line.description}</p>
                      {prod?.name && (
                        <p className="text-xs text-gray-400 mt-0.5">{prod.code} — {prod.name}</p>
                      )}
                    </td>
                    <td className="px-4 py-3 text-gray-700 whitespace-nowrap">
                      {line.quantity} <span className="text-gray-400">{line.unit}</span>
                    </td>
                    <td className="px-4 py-3 text-gray-500 text-xs">{line.discipline ?? "—"}</td>
                    <td className="px-4 py-3 text-gray-600 text-xs">{mfr?.name ?? "—"}</td>
                    <td className="px-4 py-3">
                      <span className={`bep-badge ${STATUS_COLORS[line.status]}`}>
                        {STATUS_LABELS[line.status] ?? line.status}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-xs text-gray-400">v{line.version}</td>
                    <td className="px-4 py-3">
                      <Link
                        href={`/projects/${params.id}/bom/${line.id}`}
                        className="opacity-0 group-hover:opacity-100 text-gray-400 hover:text-gray-700 transition-all"
                      >
                        <ChevronRight size={16} />
                      </Link>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
