import { NextRequest, NextResponse } from "next/server";
import { createBepServerClient } from "@core/supabase/bep";

export const maxDuration = 60; // Vercel: allow up to 60s for AI processing

export async function POST(request: NextRequest) {
  try {
    const { documentId, projectId } = await request.json();

    if (!documentId || !projectId) {
      return NextResponse.json({ error: "Missing documentId or projectId" }, { status: 400 });
    }

    const supabase = createBepServerClient();

    // 1. Mark document as processing
    await supabase
      .from("documents")
      .update({ status: "processing" })
      .eq("id", documentId);

    // 2. Fetch document metadata
    const { data: doc } = await supabase
      .from("documents")
      .select("storage_path, name, mime_type, type")
      .eq("id", documentId)
      .single();

    if (!doc) {
      throw new Error(`Document ${documentId} not found`);
    }

    // 3. Download file from storage
    const { data: fileData, error: downloadError } = await supabase.storage
      .from("bep-documents")
      .download(doc.storage_path);

    if (downloadError || !fileData) {
      throw new Error(`Storage download failed: ${downloadError?.message}`);
    }

    // 4. Extract text based on MIME type
    // For now: PDF text extraction via Anthropic, extensible to other types
    let extractedText = "";
    let aiSummary = "";
    let aiTags: string[] = [];
    let aiManufacturers: string[] = [];
    let aiNorms: string[] = [];
    let discipline = "";
    let aiQuantities: Record<string, unknown> = {};

    const isPdf = doc.mime_type === "application/pdf";
    const isText = doc.mime_type.startsWith("text/");

    if (isPdf || isText) {
      // Convert to base64 for Anthropic API
      const buffer = await fileData.arrayBuffer();
      const base64 = Buffer.from(buffer).toString("base64");

      const analysisPrompt = `Sos un ingeniero especialista en licitaciones técnicas de infraestructura TI y Data Centers.

Analizá el siguiente documento técnico y extraé la siguiente información en formato JSON exacto:

{
  "summary": "Resumen ejecutivo en español, máximo 3 párrafos",
  "discipline": "Una de: Eléctrico | Mecánico | Civil | TI | Telecomunicaciones | Seguridad | General",
  "tags": ["array", "de", "tags", "relevantes", "máximo 10"],
  "manufacturers": ["lista de fabricantes o marcas mencionados"],
  "norms": ["lista de normas, estándares y certificaciones mencionados (IEC, IEEE, ANSI, etc.)"],
  "quantities": {
    "descripcion_del_item": "cantidad y unidad"
  }
}

Respondé ÚNICAMENTE con el JSON, sin texto adicional ni markdown.`;

      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": process.env.ANTHROPIC_API_KEY!,
          "anthropic-version": "2023-06-01",
        },
        body: JSON.stringify({
          model: "claude-sonnet-4-6",
          max_tokens: 2000,
          messages: [
            {
              role: "user",
              content: isPdf
                ? [
                    {
                      type: "document",
                      source: {
                        type: "base64",
                        media_type: "application/pdf",
                        data: base64,
                      },
                    },
                    { type: "text", text: analysisPrompt },
                  ]
                : analysisPrompt + "\n\nDocumento:\n" + (await fileData.text()),
            },
          ],
        }),
      });

      if (response.ok) {
        const aiData = await response.json();
        const rawText = aiData.content?.find((c: any) => c.type === "text")?.text ?? "";

        try {
          const parsed = JSON.parse(rawText.replace(/```json|```/g, "").trim());
          aiSummary = parsed.summary ?? "";
          discipline = parsed.discipline ?? "";
          aiTags = Array.isArray(parsed.tags) ? parsed.tags : [];
          aiManufacturers = Array.isArray(parsed.manufacturers) ? parsed.manufacturers : [];
          aiNorms = Array.isArray(parsed.norms) ? parsed.norms : [];
          aiQuantities = typeof parsed.quantities === "object" ? parsed.quantities : {};
          extractedText = rawText; // Store the full raw response as extracted text for now
        } catch {
          // JSON parse failed — store raw response as summary
          aiSummary = rawText.slice(0, 500);
        }
      }
    }

    // 5. Generate embedding for semantic search (OpenAI)
    let embedding: number[] | null = null;
    const textForEmbedding = [doc.name, aiSummary, aiTags.join(" "), aiNorms.join(" ")]
      .filter(Boolean)
      .join("\n")
      .slice(0, 8000);

    if (process.env.OPENAI_API_KEY && textForEmbedding) {
      const embResponse = await fetch("https://api.openai.com/v1/embeddings", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
        },
        body: JSON.stringify({
          model: "text-embedding-3-small",
          input: textForEmbedding,
        }),
      });

      if (embResponse.ok) {
        const embData = await embResponse.json();
        embedding = embData.data?.[0]?.embedding ?? null;
      }
    }

    // 6. Update document with extracted data
    await supabase
      .from("documents")
      .update({
        status: "indexed",
        extracted_text: extractedText.slice(0, 100_000), // 100K char limit
        ai_summary: aiSummary,
        ai_tags: aiTags,
        ai_manufacturers: aiManufacturers,
        ai_norms: aiNorms,
        ai_quantities: aiQuantities,
        discipline: discipline || null,
        embedding: embedding ? JSON.stringify(embedding) : null,
      })
      .eq("id", documentId);

    return NextResponse.json({
      success: true,
      documentId,
      discipline,
      tagsFound: aiTags.length,
      manufacturersFound: aiManufacturers.length,
      normsFound: aiNorms.length,
      embeddingGenerated: !!embedding,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    console.error("[BEP] Document processing error:", message);

    // Mark document as error
    try {
      const { documentId } = await request.json().catch(() => ({}));
      if (documentId) {
        const supabase = createBepServerClient();
        await supabase.from("documents").update({ status: "error" }).eq("id", documentId);
      }
    } catch {}

    return NextResponse.json({ error: message }, { status: 500 });
  }
}
