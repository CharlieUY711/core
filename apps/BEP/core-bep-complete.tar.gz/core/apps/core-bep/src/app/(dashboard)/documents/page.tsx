import { createClient } from "@/lib/supabase/server";
import Link from "next/link";
import { FileText, Search } from "lucide-react";

export const metadata = { title: "Documentos" };

export default async function AllDocumentsPage() {
  const supabase = createClient();

  const { data: documents } = await supabase
    .from("documents")
    .select(`
      id, name, type, status, discipline, version, size_bytes, created_at, ai_tags,
      projects ( id, code, name )
    `)
    .order("created_at", { ascending: false })
    .limit(100);

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900">Todos los documentos</h1>
          <p className="text-sm text-gray-500 mt-1">Vista global entre proyectos</p>
        </div>
        <div className="relative">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            type="search"
            placeholder="Buscar en documentos..."
            className="bep-input pl-9 w-72"
          />
        </div>
      </div>

      {!documents?.length ? (
        <div className="bep-card p-16 text-center">
          <FileText size={40} className="mx-auto text-gray-200 mb-4" />
          <p className="text-gray-500">No hay documentos todavía</p>
          <p className="text-sm text-gray-400 mt-1">
            Subí documentos desde un proyecto para que aparezcan acá.
          </p>
        </div>
      ) : (
        <div className="bep-card overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-100 bg-gray-50">
                <th className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase tracking-wide">Documento</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase tracking-wide">Proyecto</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase tracking-wide">Tipo</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase tracking-wide">Estado IA</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase tracking-wide">Fecha</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {documents.map((doc) => {
                const project = doc.projects as any;
                return (
                  <tr key={doc.id} className="hover:bg-gray-50">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <FileText size={14} className="text-gray-400" />
                        <Link
                          href={`/projects/${project?.id}/documents/${doc.id}`}
                          className="font-medium text-gray-900 hover:text-brand-600"
                        >
                          {doc.name}
                        </Link>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      {project && (
                        <Link
                          href={`/projects/${project.id}`}
                          className="text-xs text-brand-600 hover:underline font-mono"
                        >
                          {project.code}
                        </Link>
                      )}
                    </td>
                    <td className="px-4 py-3 text-xs text-gray-500 capitalize">{doc.type}</td>
                    <td className="px-4 py-3">
                      <span className={`bep-badge text-xs ${
                        doc.status === "indexed"    ? "bg-green-100 text-green-700" :
                        doc.status === "processing" ? "bg-yellow-100 text-yellow-700" :
                        doc.status === "error"      ? "bg-red-100 text-red-600" :
                        "bg-gray-100 text-gray-600"
                      }`}>
                        {doc.status}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-xs text-gray-400">
                      {new Date(doc.created_at).toLocaleDateString("es-UY")}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
