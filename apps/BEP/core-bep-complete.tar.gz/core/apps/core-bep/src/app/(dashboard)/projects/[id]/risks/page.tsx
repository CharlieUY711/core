import { createClient } from "@/lib/supabase/server";
import Link from "next/link";
import { ArrowLeft, AlertTriangle, Plus } from "lucide-react";

type Prob = "low" | "medium" | "high" | "critical";
type Impact = "low" | "medium" | "high" | "critical";

const LEVEL_COLORS: Record<string, string> = {
  low:      "bg-green-100 text-green-700",
  medium:   "bg-yellow-100 text-yellow-700",
  high:     "bg-orange-100 text-orange-700",
  critical: "bg-red-100 text-red-600",
};

const LEVEL_LABELS: Record<string, string> = {
  low: "Bajo", medium: "Medio", high: "Alto", critical: "Crítico",
};

const STATUS_COLORS: Record<string, string> = {
  open:       "bg-red-100 text-red-600",
  mitigating: "bg-yellow-100 text-yellow-700",
  closed:     "bg-green-100 text-green-700",
  accepted:   "bg-gray-100 text-gray-600",
};

const STATUS_LABELS: Record<string, string> = {
  open: "Abierto", mitigating: "Mitigando", closed: "Cerrado", accepted: "Aceptado",
};

// Risk score = probability × impact (1=low, 2=medium, 3=high, 4=critical)
const SCORE_MAP: Record<string, number> = { low: 1, medium: 2, high: 3, critical: 4 };

function riskScore(prob: string, impact: string) {
  return (SCORE_MAP[prob] ?? 1) * (SCORE_MAP[impact] ?? 1);
}

function riskLevel(score: number): string {
  if (score <= 2) return "low";
  if (score <= 4) return "medium";
  if (score <= 9) return "high";
  return "critical";
}

export default async function RisksPage({ params }: { params: { id: string } }) {
  const supabase = createClient();

  const [{ data: project }, { data: risks }] = await Promise.all([
    supabase.from("projects").select("name, code").eq("id", params.id).single(),
    supabase
      .from("risks")
      .select("id, title, description, probability, impact, status, mitigation, due_date, created_at")
      .eq("project_id", params.id)
      .order("created_at", { ascending: false }),
  ]);

  const open = risks?.filter((r) => r.status === "open").length ?? 0;
  const critical = risks?.filter((r) => riskLevel(riskScore(r.probability, r.impact)) === "critical").length ?? 0;

  return (
    <div>
      <Link
        href={`/projects/${params.id}`}
        className="inline-flex items-center gap-1 text-sm text-gray-500 hover:text-gray-800 mb-6"
      >
        <ArrowLeft size={14} /> {project?.code} — {project?.name}
      </Link>

      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-semibold text-gray-900">Registro de Riesgos</h1>
          <p className="text-sm text-gray-500 mt-0.5">
            {risks?.length ?? 0} riesgos · {open} abiertos · {critical} críticos
          </p>
        </div>
        <div className="flex gap-2">
          <button className="bep-btn-secondary text-sm">✨ Detectar con IA</button>
          <Link href={`/projects/${params.id}/risks/new`} className="bep-btn-primary">
            <Plus size={15} /> Nuevo riesgo
          </Link>
        </div>
      </div>

      {/* Risk matrix visual hint */}
      {(risks?.length ?? 0) > 0 && (
        <div className="grid grid-cols-4 gap-3 mb-6">
          {(["critical", "high", "medium", "low"] as const).map((level) => {
            const count = risks?.filter((r) =>
              riskLevel(riskScore(r.probability, r.impact)) === level
            ).length ?? 0;
            return (
              <div key={level} className={`bep-card p-4 border-l-4 ${
                level === "critical" ? "border-red-400" :
                level === "high" ? "border-orange-400" :
                level === "medium" ? "border-yellow-400" : "border-green-400"
              }`}>
                <p className="text-2xl font-semibold text-gray-900">{count}</p>
                <p className="text-xs text-gray-500 mt-0.5">{LEVEL_LABELS[level]}</p>
              </div>
            );
          })}
        </div>
      )}

      {!risks?.length ? (
        <div className="bep-card p-16 text-center">
          <AlertTriangle size={40} className="mx-auto text-gray-200 mb-4" />
          <p className="text-gray-500 font-medium">Sin riesgos registrados</p>
          <p className="text-sm text-gray-400 mt-1 mb-6">
            La IA puede detectar riesgos automáticamente desde el pliego, contratos y documentos técnicos.
          </p>
          <div className="flex gap-3 justify-center">
            <button className="bep-btn-primary inline-flex">✨ Detectar con IA</button>
            <Link href={`/projects/${params.id}/risks/new`} className="bep-btn-secondary inline-flex">
              <Plus size={15} /> Agregar manual
            </Link>
          </div>
        </div>
      ) : (
        <div className="bep-card overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-100 bg-gray-50">
                <th className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase tracking-wide">Riesgo</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase tracking-wide">Probabilidad</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase tracking-wide">Impacto</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase tracking-wide">Nivel</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase tracking-wide">Estado</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase tracking-wide">Mitigación</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-gray-500 uppercase tracking-wide">Vence</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {risks
                .sort((a, b) => riskScore(b.probability, b.impact) - riskScore(a.probability, a.impact))
                .map((risk) => {
                  const score = riskScore(risk.probability, risk.impact);
                  const level = riskLevel(score);
                  return (
                    <tr key={risk.id} className="hover:bg-gray-50 transition-colors">
                      <td className="px-4 py-3 max-w-xs">
                        <Link
                          href={`/projects/${params.id}/risks/${risk.id}`}
                          className="font-medium text-gray-900 hover:text-brand-600"
                        >
                          {risk.title}
                        </Link>
                        {risk.description && (
                          <p className="text-xs text-gray-400 mt-0.5 line-clamp-1">{risk.description}</p>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        <span className={`bep-badge ${LEVEL_COLORS[risk.probability]}`}>
                          {LEVEL_LABELS[risk.probability]}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <span className={`bep-badge ${LEVEL_COLORS[risk.impact]}`}>
                          {LEVEL_LABELS[risk.impact]}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <span className={`bep-badge font-semibold ${LEVEL_COLORS[level]}`}>
                          {LEVEL_LABELS[level]} ({score})
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <span className={`bep-badge ${STATUS_COLORS[risk.status]}`}>
                          {STATUS_LABELS[risk.status]}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-xs text-gray-500 max-w-[200px]">
                        <p className="line-clamp-2">{risk.mitigation ?? "—"}</p>
                      </td>
                      <td className="px-4 py-3 text-xs text-gray-400">
                        {risk.due_date
                          ? new Date(risk.due_date).toLocaleDateString("es-UY")
                          : "—"}
                      </td>
                    </tr>
                  );
                })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
