import { createClient } from "@/lib/supabase/server";
import Link from "next/link";
import { ArrowLeft, MessageSquare, Bell, Plus, CheckCircle2, Clock } from "lucide-react";

export default async function QueriesPage({ params }: { params: { id: string } }) {
  const supabase = createClient();

  const [{ data: project }, { data: circulars }, { data: queries }] = await Promise.all([
    supabase.from("projects").select("name, code").eq("id", params.id).single(),
    supabase
      .from("circulars")
      .select("id, ref, title, issued_at, affects_bom, affects_compliance, ai_summary")
      .eq("project_id", params.id)
      .order("issued_at", { ascending: false }),
    supabase
      .from("project_queries")
      .select("id, question, answer, status, created_at, answered_at, circular_id")
      .eq("project_id", params.id)
      .order("created_at", { ascending: false }),
  ]);

  const openQueries = queries?.filter((q) => q.status === "open").length ?? 0;
  const affectingBom = circulars?.filter((c) => c.affects_bom).length ?? 0;

  return (
    <div>
      <Link
        href={`/projects/${params.id}`}
        className="inline-flex items-center gap-1 text-sm text-gray-500 hover:text-gray-800 mb-6"
      >
        <ArrowLeft size={14} /> {project?.code} — {project?.name}
      </Link>

      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-semibold text-gray-900">Consultas y Circulares</h1>
          <p className="text-sm text-gray-500 mt-0.5">
            {circulars?.length ?? 0} circulares · {openQueries} consultas abiertas
          </p>
        </div>
        <div className="flex gap-2">
          <Link href={`/projects/${params.id}/queries/new-circular`} className="bep-btn-secondary">
            <Bell size={14} /> Nueva circular
          </Link>
          <Link href={`/projects/${params.id}/queries/new`} className="bep-btn-primary">
            <Plus size={14} /> Nueva consulta
          </Link>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

        {/* Circulars */}
        <div>
          <h2 className="text-sm font-medium text-gray-700 mb-3 flex items-center gap-2">
            <Bell size={15} className="text-gray-400" />
            Circulares
            {affectingBom > 0 && (
              <span className="bep-badge bg-orange-100 text-orange-700">
                {affectingBom} afectan BOM
              </span>
            )}
          </h2>

          {!circulars?.length ? (
            <div className="bep-card p-10 text-center">
              <Bell size={28} className="mx-auto text-gray-200 mb-3" />
              <p className="text-sm text-gray-500">Sin circulares</p>
              <Link
                href={`/projects/${params.id}/queries/new-circular`}
                className="bep-btn-secondary text-xs mt-4 inline-flex"
              >
                <Plus size={13} /> Agregar circular
              </Link>
            </div>
          ) : (
            <div className="space-y-2">
              {circulars.map((c) => (
                <div key={c.id} className="bep-card p-4">
                  <div className="flex items-start justify-between gap-3 mb-2">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded">
                        {c.ref}
                      </span>
                      {c.affects_bom && (
                        <span className="bep-badge bg-orange-100 text-orange-700">Afecta BOM</span>
                      )}
                      {c.affects_compliance && (
                        <span className="bep-badge bg-red-100 text-red-600">Afecta cumplim.</span>
                      )}
                    </div>
                    {c.issued_at && (
                      <span className="text-xs text-gray-400 whitespace-nowrap">
                        {new Date(c.issued_at).toLocaleDateString("es-UY")}
                      </span>
                    )}
                  </div>
                  <h3 className="font-medium text-gray-900 text-sm mb-1">{c.title}</h3>
                  {c.ai_summary && (
                    <p className="text-xs text-gray-500 line-clamp-2 bg-brand-50 px-2 py-1.5 rounded">
                      ✨ {c.ai_summary}
                    </p>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Queries */}
        <div>
          <h2 className="text-sm font-medium text-gray-700 mb-3 flex items-center gap-2">
            <MessageSquare size={15} className="text-gray-400" />
            Consultas al cliente
            {openQueries > 0 && (
              <span className="bep-badge bg-yellow-100 text-yellow-700">{openQueries} abiertas</span>
            )}
          </h2>

          {!queries?.length ? (
            <div className="bep-card p-10 text-center">
              <MessageSquare size={28} className="mx-auto text-gray-200 mb-3" />
              <p className="text-sm text-gray-500">Sin consultas</p>
              <Link
                href={`/projects/${params.id}/queries/new`}
                className="bep-btn-secondary text-xs mt-4 inline-flex"
              >
                <Plus size={13} /> Agregar consulta
              </Link>
            </div>
          ) : (
            <div className="space-y-2">
              {queries.map((q) => (
                <div key={q.id} className="bep-card p-4">
                  <div className="flex items-start gap-3">
                    <div className="mt-0.5 flex-shrink-0">
                      {q.status === "answered" ? (
                        <CheckCircle2 size={16} className="text-green-500" />
                      ) : (
                        <Clock size={16} className="text-yellow-500" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-gray-800 font-medium line-clamp-2">{q.question}</p>
                      {q.answer && (
                        <div className="mt-2 bg-green-50 border border-green-100 rounded-lg px-3 py-2">
                          <p className="text-xs text-green-800 line-clamp-3">{q.answer}</p>
                          {q.answered_at && (
                            <p className="text-xs text-green-500 mt-1">
                              Respondida {new Date(q.answered_at).toLocaleDateString("es-UY")}
                            </p>
                          )}
                        </div>
                      )}
                      <p className="text-xs text-gray-400 mt-1">
                        {new Date(q.created_at).toLocaleDateString("es-UY")}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
