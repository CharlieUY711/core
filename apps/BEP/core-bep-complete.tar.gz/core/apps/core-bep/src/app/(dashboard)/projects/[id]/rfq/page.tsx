import { createClient } from "@/lib/supabase/server";
import Link from "next/link";
import { ArrowLeft, ShoppingCart, Plus, Send, Clock } from "lucide-react";

const RFQ_STATUS: Record<string, { label: string; color: string }> = {
  draft:    { label: "Borrador", color: "bg-gray-100 text-gray-600" },
  sent:     { label: "Enviado",  color: "bg-blue-100 text-blue-700" },
  partial:  { label: "Parcial",  color: "bg-yellow-100 text-yellow-700" },
  complete: { label: "Completo", color: "bg-green-100 text-green-700" },
  closed:   { label: "Cerrado",  color: "bg-gray-100 text-gray-500" },
};

export default async function RfqPage({ params }: { params: { id: string } }) {
  const supabase = createClient();

  const [{ data: project }, { data: rfqs }] = await Promise.all([
    supabase.from("projects").select("name, code, currency").eq("id", params.id).single(),
    supabase
      .from("rfqs")
      .select(`
        id, code, title, status, sent_at, due_at, version, created_at,
        quotes ( id, status, total, currency, supplier_id, organizations:supplier_id ( name ) )
      `)
      .eq("project_id", params.id)
      .order("created_at", { ascending: false }),
  ]);

  const totalRfqs = rfqs?.length ?? 0;
  const sentRfqs = rfqs?.filter((r) => r.status !== "draft").length ?? 0;
  const totalQuotes = rfqs?.reduce((acc, r) => acc + ((r.quotes as any[])?.length ?? 0), 0) ?? 0;

  return (
    <div>
      <Link
        href={`/projects/${params.id}`}
        className="inline-flex items-center gap-1 text-sm text-gray-500 hover:text-gray-800 mb-6"
      >
        <ArrowLeft size={14} /> {project?.code} — {project?.name}
      </Link>

      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-semibold text-gray-900">RFQ / Cotizaciones</h1>
          <p className="text-sm text-gray-500 mt-0.5">
            Solicitudes de cotización y comparativos
          </p>
        </div>
        <Link href={`/projects/${params.id}/rfq/new`} className="bep-btn-primary">
          <Plus size={15} /> Nuevo RFQ
        </Link>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3 mb-6">
        {[
          { label: "RFQ creados",   value: totalRfqs },
          { label: "RFQ enviados",  value: sentRfqs },
          { label: "Cotizaciones",  value: totalQuotes },
        ].map(({ label, value }) => (
          <div key={label} className="bep-card p-4">
            <p className="text-2xl font-semibold text-gray-900">{value}</p>
            <p className="text-xs text-gray-500 mt-0.5">{label}</p>
          </div>
        ))}
      </div>

      {!rfqs?.length ? (
        <div className="bep-card p-16 text-center">
          <ShoppingCart size={40} className="mx-auto text-gray-200 mb-4" />
          <p className="text-gray-500 font-medium">Sin RFQ todavía</p>
          <p className="text-sm text-gray-400 mt-1 mb-6">
            Creá solicitudes de cotización a partir de las líneas del BOM.
          </p>
          <Link href={`/projects/${params.id}/rfq/new`} className="bep-btn-primary inline-flex">
            <Plus size={15} /> Crear primer RFQ
          </Link>
        </div>
      ) : (
        <div className="space-y-3">
          {rfqs.map((rfq) => {
            const quotes = (rfq.quotes as any[]) ?? [];
            const statusCfg = RFQ_STATUS[rfq.status] ?? RFQ_STATUS.draft;
            const isOverdue = rfq.due_at && new Date(rfq.due_at) < new Date() && rfq.status !== "complete";

            return (
              <div key={rfq.id} className="bep-card p-5">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    {/* Header row */}
                    <div className="flex items-center gap-3 mb-2">
                      <span className="font-mono text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded">
                        {rfq.code}
                      </span>
                      <span className={`bep-badge ${statusCfg.color}`}>{statusCfg.label}</span>
                      {isOverdue && (
                        <span className="bep-badge bg-red-100 text-red-600">⚠ Vencido</span>
                      )}
                      <span className="text-xs text-gray-400">v{rfq.version}</span>
                    </div>

                    <h3 className="font-medium text-gray-900 mb-1">{rfq.title}</h3>

                    {/* Dates */}
                    <div className="flex gap-4 text-xs text-gray-500">
                      {rfq.sent_at && (
                        <span className="flex items-center gap-1">
                          <Send size={11} />
                          Enviado {new Date(rfq.sent_at).toLocaleDateString("es-UY")}
                        </span>
                      )}
                      {rfq.due_at && (
                        <span className={`flex items-center gap-1 ${isOverdue ? "text-red-500" : ""}`}>
                          <Clock size={11} />
                          Vence {new Date(rfq.due_at).toLocaleDateString("es-UY")}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-2">
                    <Link
                      href={`/projects/${params.id}/rfq/${rfq.id}`}
                      className="bep-btn-secondary text-xs"
                    >
                      Ver detalle
                    </Link>
                    {rfq.status === "draft" && (
                      <button className="bep-btn-primary text-xs">
                        <Send size={13} /> Enviar
                      </button>
                    )}
                  </div>
                </div>

                {/* Quotes received */}
                {quotes.length > 0 && (
                  <div className="mt-4 pt-4 border-t border-gray-100">
                    <p className="text-xs font-medium text-gray-500 mb-2">
                      {quotes.length} cotización{quotes.length !== 1 ? "es" : ""} recibida{quotes.length !== 1 ? "s" : ""}
                    </p>
                    <div className="flex gap-2 flex-wrap">
                      {quotes.map((q: any) => (
                        <div
                          key={q.id}
                          className="flex items-center gap-2 bg-gray-50 border border-gray-200 rounded-lg px-3 py-1.5 text-xs"
                        >
                          <span className="font-medium text-gray-700">
                            {q.organizations?.name ?? "Proveedor"}
                          </span>
                          {q.total && (
                            <span className="text-gray-900 font-semibold">
                              {q.currency} {Number(q.total).toLocaleString("es-UY")}
                            </span>
                          )}
                          <span className={`bep-badge ${
                            q.status === "approved" ? "bg-green-100 text-green-700" :
                            q.status === "rejected" ? "bg-red-100 text-red-600" :
                            "bg-gray-100 text-gray-600"
                          }`}>
                            {q.status}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
