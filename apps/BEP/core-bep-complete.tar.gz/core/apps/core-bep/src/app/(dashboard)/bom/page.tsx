import { createClient } from "@/lib/supabase/server";
import Link from "next/link";

export default async function GlobalModulePage() {
  const supabase = createClient();
  const { data: projects } = await supabase
    .from("projects")
    .select("id, code, name, status")
    .order("created_at", { ascending: false });

  return (
    <div>
      <h1 className="text-2xl font-semibold text-gray-900 mb-2">Seleccioná un proyecto</h1>
      <p className="text-sm text-gray-500 mb-8">Elegí el proyecto para acceder a este módulo.</p>
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {projects?.map((p) => (
          <Link key={p.id} href={`/projects/${p.id}`} className="bep-card p-5 hover:shadow-md transition-shadow block">
            <span className="font-mono text-xs text-gray-500 bg-gray-100 px-2 py-0.5 rounded">{p.code}</span>
            <p className="font-medium text-gray-900 mt-2">{p.name}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
