'use client'
import { useState, useEffect, useCallback } from 'react'

interface App {
  id: string; name_es: string; status: string
  vercel_project_id: string | null
  vercel_project_name: string | null
  repo_url: string | null
  repo_branch: string | null
  palette_id: string | null
  design_id: string | null
}

interface DeployInfo {
  uid: string
  state: 'READY' | 'ERROR' | 'BUILDING' | 'QUEUED' | 'CANCELED'
  url: string
  createdAt: number
  meta?: { githubCommitMessage?: string; githubCommitRef?: string }
}

interface Props {
  apps: App[]
  initialApp?: App | null
}

export default function ReleasePanel({ apps, initialApp }: Props) {
  const [selectedId, setSelectedId] = useState<string>(initialApp?.id ?? apps[0]?.id ?? '')
  const [deploy, setDeploy]         = useState<DeployInfo | null>(null)
  const [loading, setLoading]       = useState(false)
  const [releasing, setReleasing]   = useState(false)
  const [msg, setMsg]               = useState('')

  const selectedApp = apps.find(a => a.id === selectedId) ?? null

  const fetchDeploy = useCallback(async () => {
    if (!selectedApp?.vercel_project_id) return
    setLoading(true)
    try {
      const res = await fetch(`/api/admin/vercel/deployments?projectId=${selectedApp.vercel_project_id}`)
      const data = await res.json()
      setDeploy(data.deployment ?? null)
    } catch {
      setDeploy(null)
    } finally {
      setLoading(false)
    }
  }, [selectedApp?.vercel_project_id])

  useEffect(() => { fetchDeploy() }, [fetchDeploy])

  async function handleRelease() {
    if (!selectedApp?.vercel_project_id) return
    setReleasing(true); setMsg('')
    try {
      const res = await fetch('/api/admin/vercel/deploy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ projectId: selectedApp.vercel_project_id }),
      })
      const data = await res.json()
      if (data.error) { setMsg('Error: ' + data.error); return }
      setMsg('Deploy iniciado. Puede tardar 1-2 min.')
      setTimeout(fetchDeploy, 5000)
    } catch (e: unknown) {
      setMsg('Error al conectar con Vercel.')
    } finally {
      setReleasing(false)
    }
  }

  const stateColor: Record<string, string> = {
    READY: 'var(--color-green)', ERROR: '#ef4444',
    BUILDING: 'var(--color-blue)', QUEUED: 'var(--color-gold)', CANCELED: 'var(--color-text-3)'
  }

  return (
    <div>
      {/* Header */}
      <div style={{ marginBottom: '32px' }}>
        <h2 style={{ fontSize: '16px', fontWeight: 600, color: 'var(--color-text)', marginBottom: '6px' }}>Release</h2>
        <p style={{ fontSize: '13px', color: 'var(--color-text-3)' }}>Monitoreá y disparás deploys por app.</p>
      </div>

      {/* App selector */}
      <div style={{ marginBottom: '28px' }}>
        <Label>SELECCIONAR APP</Label>
        <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
          {apps.map(a => (
            <button key={a.id} onClick={() => setSelectedId(a.id)} style={{
              fontFamily: 'var(--font-mono)', fontSize: '10px', padding: '6px 14px',
              borderRadius: '6px', cursor: 'pointer', transition: 'all 0.15s',
              border: selectedId === a.id ? '1px solid var(--color-gold)' : '1px solid var(--color-border)',
              color: selectedId === a.id ? 'var(--color-gold)' : 'var(--color-text-3)',
              background: selectedId === a.id ? 'rgba(201,168,76,0.08)' : 'transparent',
            }}>{a.name_es}</button>
          ))}
        </div>
      </div>

      {selectedApp && (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>

          {/* App info */}
          <div style={{ padding: '24px', borderRadius: '12px', border: '1px solid var(--color-border)', background: 'rgba(15,56,117,0.05)' }}>
            <SectionDivider label="APP" />
            <Row label="ID"      value={selectedApp.id} />
            <Row label="Nombre"  value={selectedApp.name_es} />
            <Row label="Estado"  value={selectedApp.status.toUpperCase()} color={selectedApp.status === 'live' ? 'var(--color-green)' : 'var(--color-blue)'} />
            <Row label="Paleta"  value={selectedApp.palette_id  ?? '—'} dim={!selectedApp.palette_id} />
            <Row label="Diseño"  value={selectedApp.design_id   ?? '—'} dim={!selectedApp.design_id} />
            <Row label="Rama"    value={selectedApp.repo_branch ?? 'main'} />
            {selectedApp.repo_url && (
              <div style={{ marginTop: '16px' }}>
                <a href={selectedApp.repo_url} target="_blank" rel="noreferrer" style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--color-blue)', textDecoration: 'none' }}>
                  ↗ Ver repositorio
                </a>
              </div>
            )}
          </div>

          {/* Deploy info */}
          <div style={{ padding: '24px', borderRadius: '12px', border: '1px solid var(--color-border)', background: 'rgba(15,56,117,0.05)' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '16px' }}>
              <SectionDivider label="ÚLTIMO DEPLOY" />
              <button onClick={fetchDeploy} style={{ fontFamily: 'var(--font-mono)', fontSize: '9px', color: 'var(--color-text-3)', background: 'none', border: 'none', cursor: 'pointer' }}>
                ↺ REFRESH
              </button>
            </div>

            {!selectedApp.vercel_project_id ? (
              <p style={{ fontSize: '12px', color: 'var(--color-text-3)' }}>Sin Vercel Project ID configurado. Editá la app en ⚙ CONFIG.</p>
            ) : loading ? (
              <p style={{ fontFamily: 'var(--font-mono)', fontSize: '11px', color: 'var(--color-text-3)' }}>Cargando…</p>
            ) : deploy ? (
              <>
                <Row label="Estado"  value={deploy.state} color={stateColor[deploy.state]} />
                <Row label="Fecha"   value={new Date(deploy.createdAt).toLocaleString('es-UY')} />
                {deploy.meta?.githubCommitRef     && <Row label="Rama"   value={deploy.meta.githubCommitRef} />}
                {deploy.meta?.githubCommitMessage && <Row label="Commit" value={deploy.meta.githubCommitMessage.slice(0, 60)} />}
                {deploy.url && (
                  <div style={{ marginTop: '16px' }}>
                    <a href={`https://${deploy.url}`} target="_blank" rel="noreferrer" style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--color-blue)', textDecoration: 'none' }}>
                      ↗ Ver deployment
                    </a>
                  </div>
                )}
              </>
            ) : (
              <p style={{ fontSize: '12px', color: 'var(--color-text-3)' }}>No se encontró información de deploy.</p>
            )}
          </div>
        </div>
      )}

      {/* Release button */}
      {selectedApp && (
        <div style={{ marginTop: '28px', display: 'flex', alignItems: 'center', gap: '16px' }}>
          <button
            onClick={handleRelease}
            disabled={releasing || !selectedApp.vercel_project_id}
            style={{
              fontFamily: 'var(--font-mono)', fontSize: '11px', padding: '10px 24px',
              borderRadius: '8px', border: '1px solid var(--color-gold)',
              color: 'var(--color-gold)', background: 'rgba(201,168,76,0.1)',
              cursor: selectedApp.vercel_project_id ? 'pointer' : 'not-allowed',
              opacity: releasing ? 0.6 : 1, transition: 'all 0.15s',
              letterSpacing: '0.08em',
            }}
          >
            {releasing ? '▶ DESPLEGANDO…' : '▶ RELEASE'}
          </button>
          {msg && <span style={{ fontSize: '12px', color: msg.startsWith('Error') ? '#ef4444' : 'var(--color-green)' }}>{msg}</span>}
        </div>
      )}
    </div>
  )
}

function Row({ label, value, color, dim }: { label: string; value: string; color?: string; dim?: boolean }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '6px 0', borderBottom: '1px solid rgba(30,51,84,0.4)' }}>
      <span style={{ fontFamily: 'var(--font-mono)', fontSize: '9px', letterSpacing: '0.08em', color: 'var(--color-text-3)' }}>{label}</span>
      <span style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: color ?? (dim ? 'rgba(100,120,150,0.4)' : 'var(--color-text)') }}>{value}</span>
    </div>
  )
}

function Label({ children }: { children: React.ReactNode }) {
  return <div style={{ fontFamily: 'var(--font-mono)', fontSize: '9px', letterSpacing: '0.08em', color: 'var(--color-text-3)', marginBottom: '8px' }}>{children}</div>
}

function SectionDivider({ label }: { label: string }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '12px' }}>
      <span style={{ fontFamily: 'var(--font-mono)', fontSize: '9px', letterSpacing: '0.1em', color: 'var(--color-text-3)', whiteSpace: 'nowrap' }}>{label}</span>
      <div style={{ flex: 1, height: '1px', backgroundColor: 'var(--color-border)' }} />
    </div>
  )
}
