'use client'
import { useState, useEffect } from 'react'
import { createClient } from '@/lib/supabase/client'

interface ConfigRow { key: string; label: string; value: string; is_secret: boolean }

const KEYS = ['vercel_token', 'github_token', 'github_owner']

export default function SettingsPanel() {
  const [rows,    setRows]    = useState<ConfigRow[]>([])
  const [values,  setValues]  = useState<Record<string, string>>({})
  const [visible, setVisible] = useState<Record<string, boolean>>({})
  const [saving,  setSaving]  = useState<string | null>(null)
  const [saved,   setSaved]   = useState<string | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function load() {
      const supabase = createClient()
      const { data } = await supabase.from('workspace_config').select('*').in('key', KEYS)
      if (data) {
        setRows(data)
        const v: Record<string, string> = {}
        data.forEach((r: ConfigRow) => { v[r.key] = r.value })
        setValues(v)
      }
      setLoading(false)
    }
    load()
  }, [])

  async function handleSave(key: string) {
    setSaving(key)
    const supabase = createClient()
    await supabase.from('workspace_config').update({ value: values[key], updated_at: new Date().toISOString() }).eq('key', key)
    setSaving(null)
    setSaved(key)
    setTimeout(() => setSaved(null), 2000)
  }

  if (loading) return <p style={{ fontFamily: 'var(--font-mono)', fontSize: '11px', color: 'var(--color-text-3)' }}>Cargando…</p>

  return (
    <div>
      <div style={{ marginBottom: '32px' }}>
        <h2 style={{ fontSize: '16px', fontWeight: 600, color: 'var(--color-text)', marginBottom: '6px' }}>Settings</h2>
        <p style={{ fontSize: '13px', color: 'var(--color-text-3)' }}>Tokens e integraciones del workspace. Los valores se guardan en Supabase y solo se leen desde el servidor.</p>
      </div>

      <SectionDivider label="INTEGRACIONES" />

      <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', maxWidth: '600px' }}>
        {rows.map(row => (
          <div key={row.key} style={{ padding: '20px', borderRadius: '10px', border: '1px solid var(--color-border)', background: 'rgba(15,56,117,0.05)' }}>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: '9px', letterSpacing: '0.08em', color: 'var(--color-text-3)', marginBottom: '8px' }}>
              {row.label.toUpperCase()}
            </div>
            <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
              <input
                type={row.is_secret && !visible[row.key] ? 'password' : 'text'}
                value={values[row.key] ?? ''}
                onChange={e => setValues(prev => ({ ...prev, [row.key]: e.target.value }))}
                placeholder={row.is_secret ? '••••••••••••••••••••' : `Ingresá ${row.label}`}
                style={{
                  flex: 1, padding: '8px 12px', borderRadius: '6px',
                  border: '1px solid var(--color-border)',
                  backgroundColor: 'rgba(30,45,66,0.6)',
                  color: 'var(--color-text)', fontSize: '12px',
                  fontFamily: 'var(--font-mono)', outline: 'none',
                }}
              />
              {row.is_secret && (
                <button
                  onClick={() => setVisible(prev => ({ ...prev, [row.key]: !prev[row.key] }))}
                  style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--color-text-3)', background: 'none', border: 'none', cursor: 'pointer', whiteSpace: 'nowrap' }}
                >
                  {visible[row.key] ? 'OCULTAR' : 'VER'}
                </button>
              )}
              <button
                onClick={() => handleSave(row.key)}
                disabled={saving === row.key}
                style={{
                  fontFamily: 'var(--font-mono)', fontSize: '10px', padding: '8px 14px',
                  borderRadius: '6px', border: '1px solid var(--color-gold)',
                  color: saved === row.key ? 'var(--color-green)' : 'var(--color-gold)',
                  borderColor: saved === row.key ? 'var(--color-green)' : 'var(--color-gold)',
                  background: 'rgba(201,168,76,0.08)', cursor: 'pointer', whiteSpace: 'nowrap',
                  transition: 'all 0.2s',
                }}
              >
                {saving === row.key ? '…' : saved === row.key ? '✓ OK' : 'GUARDAR'}
              </button>
            </div>
          </div>
        ))}
      </div>

      <div style={{ marginTop: '40px' }}>
        <SectionDivider label="INFORMACIÓN" />
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', maxWidth: '600px' }}>
          {[
            { label: 'Vercel Token', desc: 'Necesario para leer el estado de deploys y disparar nuevos releases. Generalo en vercel.com/account/tokens con scope Full Account.', url: 'https://vercel.com/account/tokens' },
            { label: 'GitHub Token', desc: 'Necesario para leer el estado de ramas y commits. Generalo en github.com/settings/tokens con scope repo.', url: 'https://github.com/settings/tokens' },
          ].map(item => (
            <div key={item.label} style={{ padding: '16px', borderRadius: '8px', border: '1px solid rgba(30,51,84,0.5)', background: 'rgba(15,56,117,0.03)' }}>
              <div style={{ fontSize: '11px', fontWeight: 600, color: 'var(--color-text)', marginBottom: '6px' }}>{item.label}</div>
              <div style={{ fontSize: '11px', color: 'var(--color-text-3)', lineHeight: 1.6, marginBottom: '10px' }}>{item.desc}</div>
              <a href={item.url} target="_blank" rel="noreferrer" style={{ fontFamily: 'var(--font-mono)', fontSize: '9px', color: 'var(--color-blue)', textDecoration: 'none' }}>↗ Ir a {item.url.replace('https://', '')}</a>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

function SectionDivider({ label }: { label: string }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '20px' }}>
      <span style={{ fontFamily: 'var(--font-mono)', fontSize: '9px', letterSpacing: '0.1em', color: 'var(--color-text-3)', whiteSpace: 'nowrap' }}>{label}</span>
      <div style={{ flex: 1, height: '1px', backgroundColor: 'var(--color-border)' }} />
    </div>
  )
}
