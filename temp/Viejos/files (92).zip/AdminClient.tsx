'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import PortalConfig from './PortalConfig'
import ReleasePanel from './ReleasePanel'
import SettingsPanel from './SettingsPanel'

interface Palette  { id: string; name: string; description: string }
interface Design   { id: string; name: string; description: string }
interface App      {
  id: string; name_es: string; status: string; access: string
  palette_id: string | null; design_id: string | null
  features: Record<string, boolean>
  vercel_project_id: string | null
  vercel_project_name: string | null
  repo_url: string | null
  repo_branch: string | null
}

interface Props {
  user:     { email: string; id: string }
  palettes: Palette[]
  designs:  Design[]
  portals:  App[]
}

type Section = 'overview' | 'palettes' | 'designs' | 'apps' | 'release' | 'settings'

export default function AdminClient({ user, palettes, designs, portals }: Props) {
  const router = useRouter()
  const [section, setSection] = useState<Section>('overview')
  const [configApp, setConfigApp]     = useState<App | null>(null)
  const [releaseApp, setReleaseApp]   = useState<App | null>(null)

  const navItems: { id: Section; label: string; count?: number }[] = [
    { id: 'overview',  label: 'OVERVIEW' },
    { id: 'palettes',  label: 'PALETAS',  count: palettes.length },
    { id: 'designs',   label: 'DISEÑOS',  count: designs.length },
    { id: 'apps',      label: 'APPS',     count: portals.length },
    { id: 'release',   label: 'RELEASE' },
    { id: 'settings',  label: 'SETTINGS' },
  ]

  return (
    <div style={{ minHeight: '100vh', backgroundColor: 'var(--bg-deep)', color: 'var(--color-text)', fontFamily: 'var(--font-base)' }}>

      {/* Top bar */}
      <header style={{ borderBottom: '1px solid var(--color-border)' }}>
        <div style={{ maxWidth: '1152px', margin: '0 auto', padding: '0 32px', height: '56px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
            <button onClick={() => router.push('/dashboard')} style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--color-text-3)', background: 'none', border: 'none', cursor: 'pointer', padding: 0 }}>
              ← WORKSPACE
            </button>
            <span style={{ color: 'var(--color-border)' }}>|</span>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--color-gold)', letterSpacing: '0.1em' }}>ADMIN PANEL</span>
          </div>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--color-text-3)' }}>{user.email}</span>
        </div>
      </header>

      {/* Nav */}
      <nav style={{ borderBottom: '1px solid var(--color-border)', backgroundColor: 'rgba(30,45,66,0.4)' }}>
        <div style={{ maxWidth: '1152px', margin: '0 auto', padding: '0 32px', display: 'flex', alignItems: 'center', gap: '2px' }}>
          {navItems.map(item => (
            <button key={item.id} onClick={() => setSection(item.id)} style={{
              fontFamily: 'var(--font-mono)', fontSize: '10px', letterSpacing: '0.1em',
              padding: '14px 16px', background: 'none', border: 'none',
              borderBottom: section === item.id ? '2px solid var(--color-gold)' : '2px solid transparent',
              color: section === item.id ? 'var(--color-gold)' : 'var(--color-text-3)',
              cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '6px',
              transition: 'color 0.15s', marginBottom: '-1px',
            }}>
              {item.label}
              {item.count !== undefined && (
                <span style={{
                  fontSize: '9px', padding: '1px 5px', borderRadius: '10px',
                  backgroundColor: section === item.id ? 'rgba(201,168,76,0.15)' : 'rgba(74,96,128,0.3)',
                  color: section === item.id ? 'var(--color-gold)' : 'var(--color-text-3)',
                }}>{item.count}</span>
              )}
            </button>
          ))}
        </div>
      </nav>

      {/* Content */}
      <main style={{ maxWidth: '1152px', margin: '0 auto', padding: '40px 32px' }}>
        {section === 'overview'  && <OverviewSection palettes={palettes} designs={designs} portals={portals} setSection={setSection} />}
        {section === 'palettes'  && <ListSection title="Paletas" items={palettes} type="palette" router={router} />}
        {section === 'designs'   && <ListSection title="Diseños" items={designs}  type="design"  router={router} />}
        {section === 'apps'      && <AppsSection apps={portals} router={router} onConfig={a => setConfigApp(a)} onRelease={a => { setReleaseApp(a); setSection('release') }} />}
        {section === 'release'   && <ReleasePanel apps={portals} initialApp={releaseApp} />}
        {section === 'settings'  && <SettingsPanel />}
      </main>

      {configApp && (
        <PortalConfig
          portal={configApp}
          palettes={palettes}
          designs={designs}
          onClose={() => setConfigApp(null)}
          onSaved={() => { setConfigApp(null); router.refresh() }}
        />
      )}
    </div>
  )
}

/* ── Overview ── */
function OverviewSection({ palettes, designs, portals, setSection }: {
  palettes: Palette[]; designs: Design[]; portals: App[];
  setSection: (s: Section) => void
}) {
  const stats = [
    { label: 'Paletas', value: palettes.length, section: 'palettes' as Section, color: 'var(--color-blue)' },
    { label: 'Diseños', value: designs.length,  section: 'designs'  as Section, color: 'var(--color-green)' },
    { label: 'Apps',    value: portals.length,  section: 'apps'     as Section, color: 'var(--color-gold)' },
    { label: 'Live',    value: portals.filter(p => p.status === 'live').length, section: 'apps' as Section, color: 'var(--color-green)' },
  ]
  return (
    <div>
      <div style={{ marginBottom: '32px' }}>
        <h1 style={{ fontSize: '20px', fontWeight: 600, color: 'var(--color-text)', marginBottom: '6px' }}>Design System Manager</h1>
        <p style={{ fontSize: '13px', color: 'var(--color-text-3)' }}>Gestioná paletas, diseños y apps del ecosistema CORE.</p>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '16px', marginBottom: '40px' }}>
        {stats.map(s => (
          <button key={s.label} onClick={() => setSection(s.section)} style={{
            padding: '20px', borderRadius: '12px', border: '1px solid var(--color-border)',
            background: 'rgba(15,56,117,0.06)', cursor: 'pointer', textAlign: 'left', transition: 'all 0.15s',
          }}
            onMouseEnter={e => { (e.currentTarget as HTMLElement).style.borderColor = s.color }}
            onMouseLeave={e => { (e.currentTarget as HTMLElement).style.borderColor = 'var(--color-border)' }}
          >
            <div style={{ fontSize: '28px', fontWeight: 700, color: s.color, marginBottom: '4px', fontFamily: 'var(--font-mono)' }}>{s.value}</div>
            <div style={{ fontSize: '10px', fontFamily: 'var(--font-mono)', letterSpacing: '0.1em', color: 'var(--color-text-3)' }}>{s.label.toUpperCase()}</div>
          </button>
        ))}
      </div>
      <SectionHeader label="ACCIONES RÁPIDAS" />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '12px' }}>
        {[
          { label: 'Nueva Paleta', desc: 'Definir tokens de color, tipografía y sombras',  path: '/dashboard/admin/palettes/new', color: 'var(--color-blue)' },
          { label: 'Nuevo Diseño', desc: 'Definir tokens de layout, navbar y componentes', path: '/dashboard/admin/designs/new',  color: 'var(--color-green)' },
          { label: 'Nueva App',    desc: 'Registrar una app nueva en el ecosistema CORE',  path: '/dashboard/admin/portals/new',  color: 'var(--color-gold)' },
        ].map(item => (
          <a key={item.label} href={item.path} style={{
            display: 'block', padding: '20px', borderRadius: '10px',
            border: '1px solid var(--color-border)', background: 'rgba(15,56,117,0.04)',
            textDecoration: 'none', transition: 'all 0.15s',
          }}
            onMouseEnter={e => { (e.currentTarget as HTMLElement).style.borderColor = item.color }}
            onMouseLeave={e => { (e.currentTarget as HTMLElement).style.borderColor = 'var(--color-border)' }}
          >
            <div style={{ fontSize: '13px', fontWeight: 600, color: item.color, marginBottom: '6px' }}>+ {item.label}</div>
            <div style={{ fontSize: '12px', color: 'var(--color-text-3)', lineHeight: 1.5 }}>{item.desc}</div>
          </a>
        ))}
      </div>
    </div>
  )
}

/* ── List section ── */
function ListSection({ title, items, type, router }: {
  title: string; items: { id: string; name: string; description: string }[];
  type: 'palette' | 'design'; router: ReturnType<typeof useRouter>
}) {
  const newPath = `/dashboard/admin/${type === 'palette' ? 'palettes' : 'designs'}/new`
  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '24px' }}>
        <h2 style={{ fontSize: '16px', fontWeight: 600, color: 'var(--color-text)', margin: 0 }}>{title}</h2>
        <BtnOutline label={`+ ${type === 'palette' ? 'Nueva Paleta' : 'Nuevo Diseño'}`} onClick={() => router.push(newPath)} />
      </div>
      {items.length === 0 ? (
        <EmptyState label={`No hay ${title.toLowerCase()} todavía.`} action="Creá el primero →" path={newPath} />
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: '12px' }}>
          {items.map(item => (
            <div key={item.id} style={{
              padding: '20px', borderRadius: '10px',
              border: '1px solid var(--color-border)', background: 'rgba(15,56,117,0.06)',
              display: 'flex', flexDirection: 'column', gap: '4px',
            }}>
              <div style={{ fontSize: '13px', fontWeight: 600, color: 'var(--color-text)' }}>{item.name}</div>
              <div style={{ fontSize: '11px', color: 'var(--color-text-3)', lineHeight: 1.5, flex: 1 }}>{item.description}</div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: '9px', color: 'var(--color-text-3)', letterSpacing: '0.08em', marginBottom: '12px' }}>{item.id}</div>
              <BtnOutline label="EDITAR COPIA →" onClick={() => router.push(`${newPath}?from=${item.id}`)} small />
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

/* ── Apps section ── */
function AppsSection({ apps, router, onConfig, onRelease }: {
  apps: App[]; router: ReturnType<typeof useRouter>;
  onConfig: (a: App) => void; onRelease: (a: App) => void
}) {
  const statusColor: Record<string, string> = {
    live: 'var(--color-green)', dev: 'var(--color-blue)', planned: 'var(--color-text-3)'
  }
  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '24px' }}>
        <h2 style={{ fontSize: '16px', fontWeight: 600, color: 'var(--color-text)', margin: 0 }}>Apps</h2>
        <BtnOutline label="+ Nueva App" onClick={() => router.push('/dashboard/admin/portals/new')} />
      </div>
      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr style={{ borderBottom: '1px solid var(--color-border)' }}>
            {['ID', 'Nombre', 'Estado', 'Paleta', 'Diseño', 'Vercel', ''].map(h => (
              <th key={h} style={{ fontFamily: 'var(--font-mono)', fontSize: '9px', letterSpacing: '0.1em', color: 'var(--color-text-3)', textAlign: 'left', padding: '8px 12px', fontWeight: 500 }}>
                {h.toUpperCase()}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {apps.map(a => (
            <tr key={a.id} style={{ borderBottom: '1px solid rgba(30,51,84,0.5)' }}>
              <td style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--color-text-3)', padding: '12px' }}>{a.id}</td>
              <td style={{ fontSize: '13px', color: 'var(--color-text)', padding: '12px', fontWeight: 500 }}>{a.name_es}</td>
              <td style={{ padding: '12px' }}>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: '9px', padding: '2px 8px', borderRadius: '10px', backgroundColor: `${statusColor[a.status]}22`, color: statusColor[a.status] }}>
                  {a.status.toUpperCase()}
                </span>
              </td>
              <td style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', padding: '12px' }}>
                {a.palette_id ? <span style={{ color: 'var(--color-blue)' }}>{a.palette_id}</span> : <span style={{ opacity: 0.3 }}>—</span>}
              </td>
              <td style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', padding: '12px' }}>
                {a.design_id ? <span style={{ color: 'var(--color-green)' }}>{a.design_id}</span> : <span style={{ opacity: 0.3 }}>—</span>}
              </td>
              <td style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', padding: '12px' }}>
                {a.vercel_project_id ? <span style={{ color: 'var(--color-text-3)' }}>{a.vercel_project_id.slice(0, 12)}…</span> : <span style={{ opacity: 0.3 }}>—</span>}
              </td>
              <td style={{ padding: '12px' }}>
                <div style={{ display: 'flex', gap: '6px' }}>
                  <Btn label="⚙ CONFIG"   onClick={() => onConfig(a)}  />
                  <Btn label="▶ RELEASE"  onClick={() => onRelease(a)} gold />
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

/* ── Shared ── */
function Btn({ label, onClick, gold }: { label: string; onClick: () => void; gold?: boolean }) {
  return (
    <button onClick={onClick} style={{
      fontFamily: 'var(--font-mono)', fontSize: '9px', padding: '4px 10px',
      borderRadius: '4px', border: `1px solid ${gold ? 'var(--color-gold)' : 'var(--color-border)'}`,
      color: gold ? 'var(--color-gold)' : 'var(--color-text-3)',
      background: gold ? 'rgba(201,168,76,0.08)' : 'transparent',
      cursor: 'pointer', transition: 'all 0.15s', whiteSpace: 'nowrap',
    }}
      onMouseEnter={e => { (e.currentTarget as HTMLElement).style.opacity = '0.75' }}
      onMouseLeave={e => { (e.currentTarget as HTMLElement).style.opacity = '1' }}
    >{label}</button>
  )
}

function BtnOutline({ label, onClick, small }: { label: string; onClick: () => void; small?: boolean }) {
  return (
    <button onClick={onClick} style={{
      fontFamily: 'var(--font-mono)', fontSize: small ? '9px' : '10px',
      padding: small ? '4px 10px' : '6px 14px', borderRadius: '4px',
      border: '1px solid var(--color-text)', color: 'var(--color-text)',
      background: 'transparent', cursor: 'pointer', transition: 'all 0.15s',
    }}
      onMouseEnter={e => { (e.currentTarget as HTMLElement).style.borderColor = 'var(--color-gold)'; (e.currentTarget as HTMLElement).style.color = 'var(--color-gold)' }}
      onMouseLeave={e => { (e.currentTarget as HTMLElement).style.borderColor = 'var(--color-text)'; (e.currentTarget as HTMLElement).style.color = 'var(--color-text)' }}
    >{label}</button>
  )
}

function SectionHeader({ label }: { label: string }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '16px' }}>
      <p style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', letterSpacing: '0.1em', color: 'var(--color-text-3)', whiteSpace: 'nowrap' }}>{label}</p>
      <div style={{ flex: 1, height: '1px', backgroundColor: 'var(--color-border)' }} />
    </div>
  )
}

function EmptyState({ label, action, path }: { label: string; action: string; path: string }) {
  return (
    <div style={{ padding: '48px', textAlign: 'center', border: '1px dashed var(--color-border)', borderRadius: '12px' }}>
      <p style={{ fontSize: '13px', color: 'var(--color-text-3)', marginBottom: '12px' }}>{label}</p>
      <a href={path} style={{ fontFamily: 'var(--font-mono)', fontSize: '11px', color: 'var(--color-gold)', textDecoration: 'none' }}>{action}</a>
    </div>
  )
}
