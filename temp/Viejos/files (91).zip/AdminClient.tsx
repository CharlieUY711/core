'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'

interface Palette  { id: string; name: string; description: string }
interface Design   { id: string; name: string; description: string }
interface Portal   { id: string; name_es: string; status: string; access: string }

interface Props {
  user:     { email: string; id: string }
  palettes: Palette[]
  designs:  Design[]
  portals:  Portal[]
}

type Section = 'overview' | 'palettes' | 'designs' | 'portals'

export default function AdminClient({ user, palettes, designs, portals }: Props) {
  const router = useRouter()
  const [section, setSection] = useState<Section>('overview')

  const navItems: { id: Section; label: string; count?: number }[] = [
    { id: 'overview', label: 'OVERVIEW' },
    { id: 'palettes', label: 'PALETAS',  count: palettes.length },
    { id: 'designs',  label: 'DISEÑOS',  count: designs.length },
    { id: 'portals',  label: 'PORTALES', count: portals.length },
  ]

  return (
    <div style={{ minHeight: '100vh', backgroundColor: 'var(--bg-deep)', color: 'var(--color-text)', fontFamily: 'var(--font-base)' }}>

      {/* Top bar */}
      <header style={{ borderBottom: '1px solid var(--color-border)' }}>
        <div style={{ maxWidth: '1152px', margin: '0 auto', padding: '0 32px', height: '56px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
            <button
              onClick={() => router.push('/dashboard')}
              style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--color-text-3)', background: 'none', border: 'none', cursor: 'pointer', padding: 0 }}
            >
              ← WORKSPACE
            </button>
            <span style={{ color: 'var(--color-border)' }}>|</span>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--color-gold)', letterSpacing: '0.1em' }}>
              ADMIN PANEL
            </span>
          </div>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--color-text-3)' }}>
            {user.email}
          </span>
        </div>
      </header>

      {/* Admin nav */}
      <nav style={{ borderBottom: '1px solid var(--color-border)', backgroundColor: 'rgba(30,45,66,0.4)' }}>
        <div style={{ maxWidth: '1152px', margin: '0 auto', padding: '0 32px', display: 'flex', alignItems: 'center', gap: '2px' }}>
          {navItems.map(item => (
            <button
              key={item.id}
              onClick={() => setSection(item.id)}
              style={{
                fontFamily: 'var(--font-mono)',
                fontSize: '10px',
                letterSpacing: '0.1em',
                padding: '14px 16px',
                background: 'none',
                border: 'none',
                borderBottom: section === item.id ? '2px solid var(--color-gold)' : '2px solid transparent',
                color: section === item.id ? 'var(--color-gold)' : 'var(--color-text-3)',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: '6px',
                transition: 'color 0.15s',
                marginBottom: '-1px',
              }}
            >
              {item.label}
              {item.count !== undefined && (
                <span style={{
                  fontSize: '9px',
                  padding: '1px 5px',
                  borderRadius: '10px',
                  backgroundColor: section === item.id ? 'rgba(201,168,76,0.15)' : 'rgba(74,96,128,0.3)',
                  color: section === item.id ? 'var(--color-gold)' : 'var(--color-text-3)',
                }}>
                  {item.count}
                </span>
              )}
            </button>
          ))}

          {/* Crear button — right aligned */}
          <div style={{ marginLeft: 'auto' }}>
            <CreateButton section={section} router={router} />
          </div>
        </div>
      </nav>

      {/* Content */}
      <main style={{ maxWidth: '1152px', margin: '0 auto', padding: '40px 32px' }}>
        {section === 'overview'  && <OverviewSection palettes={palettes} designs={designs} portals={portals} setSection={setSection} />}
        {section === 'palettes'  && <ListSection title="Paletas" items={palettes} type="palette" router={router} />}
        {section === 'designs'   && <ListSection title="Diseños" items={designs}  type="design"  router={router} />}
        {section === 'portals'   && <PortalsSection portals={portals} router={router} />}
      </main>
    </div>
  )
}

/* ── Create button contextual ── */
function CreateButton({ section, router }: { section: Section; router: ReturnType<typeof useRouter> }) {
  const map: Partial<Record<Section, { label: string; path: string }>> = {
    palettes: { label: '+ Nueva Paleta', path: '/dashboard/admin/palettes/new' },
    designs:  { label: '+ Nuevo Diseño', path: '/dashboard/admin/designs/new' },
    portals:  { label: '+ Nuevo Portal', path: '/dashboard/admin/portals/new' },
  }
  const action = map[section]
  if (!action) return null

  return (
    <button
      onClick={() => router.push(action.path)}
      style={{
        fontFamily: 'var(--font-mono)',
        fontSize: '10px',
        letterSpacing: '0.05em',
        padding: '6px 14px',
        borderRadius: '4px',
        border: '1px solid var(--color-gold)',
        color: 'var(--color-gold)',
        background: 'rgba(201,168,76,0.08)',
        cursor: 'pointer',
        transition: 'all 0.15s',
      }}
    >
      {action.label}
    </button>
  )
}

/* ── Overview ── */
function OverviewSection({
  palettes, designs, portals, setSection
}: {
  palettes: Palette[]; designs: Design[]; portals: Portal[];
  setSection: (s: Section) => void
}) {
  const stats = [
    { label: 'Paletas',  value: palettes.length, section: 'palettes' as Section, color: 'var(--color-blue)' },
    { label: 'Diseños',  value: designs.length,  section: 'designs'  as Section, color: 'var(--color-green)' },
    { label: 'Portales', value: portals.length,  section: 'portals'  as Section, color: 'var(--color-gold)' },
    { label: 'Activos',  value: portals.filter(p => p.status === 'live').length, section: 'portals' as Section, color: 'var(--color-green)' },
  ]

  return (
    <div>
      <div style={{ marginBottom: '32px' }}>
        <h1 style={{ fontSize: '20px', fontWeight: 600, color: 'var(--color-text)', marginBottom: '6px' }}>
          Design System Manager
        </h1>
        <p style={{ fontSize: '13px', color: 'var(--color-text-3)' }}>
          Gestioná paletas, diseños y portales del ecosistema CORE.
        </p>
      </div>

      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '16px', marginBottom: '40px' }}>
        {stats.map(s => (
          <button
            key={s.label}
            onClick={() => setSection(s.section)}
            style={{
              padding: '20px',
              borderRadius: '12px',
              border: '1px solid var(--color-border)',
              background: 'rgba(15,56,117,0.06)',
              cursor: 'pointer',
              textAlign: 'left',
              transition: 'all 0.15s',
            }}
            onMouseEnter={e => { (e.currentTarget as HTMLElement).style.borderColor = s.color; (e.currentTarget as HTMLElement).style.background = 'rgba(15,56,117,0.12)' }}
            onMouseLeave={e => { (e.currentTarget as HTMLElement).style.borderColor = 'var(--color-border)'; (e.currentTarget as HTMLElement).style.background = 'rgba(15,56,117,0.06)' }}
          >
            <div style={{ fontSize: '28px', fontWeight: 700, color: s.color, marginBottom: '4px', fontFamily: 'var(--font-mono)' }}>
              {s.value}
            </div>
            <div style={{ fontSize: '10px', fontFamily: 'var(--font-mono)', letterSpacing: '0.1em', color: 'var(--color-text-3)' }}>
              {s.label.toUpperCase()}
            </div>
          </button>
        ))}
      </div>

      {/* Quick access */}
      <SectionHeader label="ACCIONES RÁPIDAS" />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '12px' }}>
        {[
          { label: 'Nueva Paleta',  desc: 'Definir tokens de color, tipografía y sombras',     path: '/dashboard/admin/palettes/new', color: 'var(--color-blue)' },
          { label: 'Nuevo Diseño',  desc: 'Definir tokens de layout, navbar y componentes',    path: '/dashboard/admin/designs/new',  color: 'var(--color-green)' },
          { label: 'Nuevo Portal',  desc: 'Registrar una app nueva o existente en el sistema', path: '/dashboard/admin/portals/new',  color: 'var(--color-gold)' },
        ].map(item => (
          <a
            key={item.label}
            href={item.path}
            style={{
              display: 'block',
              padding: '20px',
              borderRadius: '10px',
              border: `1px solid var(--color-border)`,
              background: 'rgba(15,56,117,0.04)',
              textDecoration: 'none',
              transition: 'all 0.15s',
            }}
            onMouseEnter={e => { (e.currentTarget as HTMLElement).style.borderColor = item.color; (e.currentTarget as HTMLElement).style.background = 'rgba(15,56,117,0.1)' }}
            onMouseLeave={e => { (e.currentTarget as HTMLElement).style.borderColor = 'var(--color-border)'; (e.currentTarget as HTMLElement).style.background = 'rgba(15,56,117,0.04)' }}
          >
            <div style={{ fontSize: '13px', fontWeight: 600, color: item.color, marginBottom: '6px' }}>+ {item.label}</div>
            <div style={{ fontSize: '12px', color: 'var(--color-text-3)', lineHeight: 1.5 }}>{item.desc}</div>
          </a>
        ))}
      </div>
    </div>
  )
}

/* ── Generic list section ── */
function ListSection({
  title, items, type, router
}: {
  title: string;
  items: { id: string; name: string; description: string }[];
  type: 'palette' | 'design';
  router: ReturnType<typeof useRouter>
}) {
  const newPath = `/dashboard/admin/${type === 'palette' ? 'palettes' : 'designs'}/new`

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '24px' }}>
        <h2 style={{ fontSize: '16px', fontWeight: 600, color: 'var(--color-text)' }}>{title}</h2>
        <button
          onClick={() => router.push(newPath)}
          style={{
            fontFamily: 'var(--font-mono)', fontSize: '10px', padding: '6px 14px',
            borderRadius: '4px', border: '1px solid var(--color-gold)',
            color: 'var(--color-gold)', background: 'rgba(201,168,76,0.08)', cursor: 'pointer',
          }}
        >
          + {type === 'palette' ? 'Nueva Paleta' : 'Nuevo Diseño'}
        </button>
      </div>

      {items.length === 0 ? (
        <EmptyState label={`No hay ${title.toLowerCase()} todavía.`} action={`Creá el primero →`} path={newPath} />
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: '12px' }}>
          {items.map(item => (
            <div
              key={item.id}
              style={{
                padding: '20px', borderRadius: '10px',
                border: '1px solid var(--color-border)',
                background: 'rgba(15,56,117,0.06)',
              }}
            >
              <div style={{ fontSize: '13px', fontWeight: 600, color: 'var(--color-text)', marginBottom: '4px' }}>{item.name}</div>
              <div style={{ fontSize: '11px', color: 'var(--color-text-3)', marginBottom: '12px', lineHeight: 1.5 }}>{item.description}</div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: '9px', color: 'var(--color-text-3)', letterSpacing: '0.08em' }}>{item.id}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

/* ── Portals section ── */
function PortalsSection({ portals, router }: { portals: Portal[]; router: ReturnType<typeof useRouter> }) {
  const statusColor: Record<string, string> = {
    live: 'var(--color-green)', dev: 'var(--color-blue)', planned: 'var(--color-text-3)'
  }

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '24px' }}>
        <h2 style={{ fontSize: '16px', fontWeight: 600, color: 'var(--color-text)' }}>Portales</h2>
        <button
          onClick={() => router.push('/dashboard/admin/portals/new')}
          style={{
            fontFamily: 'var(--font-mono)', fontSize: '10px', padding: '6px 14px',
            borderRadius: '4px', border: '1px solid var(--color-gold)',
            color: 'var(--color-gold)', background: 'rgba(201,168,76,0.08)', cursor: 'pointer',
          }}
        >
          + Nuevo Portal
        </button>
      </div>

      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr style={{ borderBottom: '1px solid var(--color-border)' }}>
            {['ID', 'Nombre', 'Estado', 'Acceso'].map(h => (
              <th key={h} style={{ fontFamily: 'var(--font-mono)', fontSize: '9px', letterSpacing: '0.1em', color: 'var(--color-text-3)', textAlign: 'left', padding: '8px 12px', fontWeight: 500 }}>
                {h.toUpperCase()}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {portals.map(p => (
            <tr key={p.id} style={{ borderBottom: '1px solid rgba(30,51,84,0.5)' }}>
              <td style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--color-text-3)', padding: '12px 12px' }}>{p.id}</td>
              <td style={{ fontSize: '13px', color: 'var(--color-text)', padding: '12px 12px' }}>{p.name_es}</td>
              <td style={{ padding: '12px 12px' }}>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: '9px', padding: '2px 8px', borderRadius: '10px', backgroundColor: `${statusColor[p.status]}22`, color: statusColor[p.status] }}>
                  {p.status.toUpperCase()}
                </span>
              </td>
              <td style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', color: 'var(--color-text-3)', padding: '12px 12px' }}>{p.access}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

/* ── Helpers ── */
function SectionHeader({ label }: { label: string }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '16px' }}>
      <p style={{ fontFamily: 'var(--font-mono)', fontSize: '10px', letterSpacing: '0.1em', color: 'var(--color-text-3)', whiteSpace: 'nowrap' }}>{label}</p>
      <div style={{ flex: 1, height: '1px', backgroundColor: 'var(--color-border)' }} />
    </div>
  )
}

function EmptyState({ label, action, path }: { label: string; action: string; path: string }) {
  return (
    <div style={{ padding: '48px', textAlign: 'center', border: '1px dashed var(--color-border)', borderRadius: '12px' }}>
      <p style={{ fontSize: '13px', color: 'var(--color-text-3)', marginBottom: '12px' }}>{label}</p>
      <a href={path} style={{ fontFamily: 'var(--font-mono)', fontSize: '11px', color: 'var(--color-gold)', textDecoration: 'none' }}>{action}</a>
    </div>
  )
}
